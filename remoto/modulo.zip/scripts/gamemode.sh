#!/system/bin/sh
# Modalità gioco. Il segno del Non disturbare è salvato in modo permanente,
# così viene tolto anche se la console si riavvia durante un gioco.
DNDF=$CFG/gm_dnd
gamemode_on() {
  [ "$GAMEMODE" = on ] || return
  [ -f $RUN/gm_active ] && return
  touch $RUN/gm_active
  if [ "$GAMEMODE_DND" = on ] && [ "$(sget global zen_mode)" = 0 ]; then
    cmd notification set_dnd priority >/dev/null 2>&1 && touch $DNDF
  fi
  # chiude solo app in background "sacrificabili": musica e servizi attivi restano
  am kill-all >/dev/null 2>&1
  w 1 /proc/sys/vm/compact_memory
  log "modalità gioco ON (RAM libera: $(mb_avail) MB)"
}
dnd_restore() {
  [ -f $DNDF ] || return
  # spegne il Non disturbare solo se è ancora quello attivato dal modulo
  [ "$(sget global zen_mode)" = 1 ] && cmd notification set_dnd off >/dev/null 2>&1
  rm -f $DNDF
}
gamemode_off() {
  [ -f $RUN/gm_active ] || { dnd_restore; return; }
  rm -f $RUN/gm_active
  dnd_restore
  log "modalità gioco OFF"
}

# --- Giochi PC in locale (v4.17). Android chiude i "processi figli" delle app (qui: Wine e Box64 del gioco Windows)
# quando sono troppi o lavorano molto. Finché un'app PC è a schermo il limite viene tolto; il valore di prima
# è salvato in modo permanente, così torna anche dopo un riavvio o se il modulo viene tolto.
PHF=$CFG/phantom_orig
is_pc_app() { [ "$PC" = auto ] || return 1; case " $PC_APPS " in *" $1 "*) return 0;; esac; return 1; }
pc_on() {
  [ -f $PHF ] && return 0
  o=$(cmd device_config get activity_manager max_phantom_processes </dev/null 2>/dev/null)
  case $o in ""|null) o=null;; *[!0-9]*) log "giochi PC: limite dei processi non leggibile, non lo tocco"; return 0;; esac
  echo $o > $PHF
  cmd device_config put activity_manager max_phantom_processes 2147483647 >/dev/null 2>&1
  log "giochi PC: Android non chiude i processi del gioco (limite di prima: $o)"
}
pc_off() {
  [ -f $PHF ] || return 0
  o=$(cat $PHF); rm -f $PHF
  if is_num "$o"; then cmd device_config put activity_manager max_phantom_processes $o >/dev/null 2>&1
  else cmd device_config delete activity_manager max_phantom_processes >/dev/null 2>&1; fi
  log "giochi PC: limite dei processi ripristinato"
}

# --- Una modalità alla volta: Cloud, PC, Server (v4.17). Decide il gioco a schermo; senza un gioco a schermo
# vince il server. Il server si ferma sempre con "stop" nella console (mondo salvato), mai con la forza.
chiudi_app() {
  for p in "$@"; do
    is_pkg "$p" && pidof $p >/dev/null 2>&1 && { am force-stop $p >/dev/null 2>&1; log "una modalità alla volta: chiusa $p"; }
  done
}
esclusiva() {  # esclusiva cloud|pc|server
  [ "$ESCLUSIVE" = on ] || return 0
  case $1 in cloud) chiudi_app $PC_APPS;; pc) chiudi_app $CLOUD_APPS;; esac
  if [ "$1" = server ] && [ ! -f $RUN/cur_modo ]; then chiudi_app $CLOUD_APPS $PC_APPS; return 0; fi
  srv_on || return 0
  if rem_stop; then
    touch $RUN/ripresa_srv
    srv_avvisa "Gioco aperto: server Minecraft fermato in modo pulito (mondo salvato). Riparte quando esci dal gioco"
  else srv_avvisa "Gioco aperto, ma il server Minecraft non risponde allo stop: resta acceso"; fi
}
