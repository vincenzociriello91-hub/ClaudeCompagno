#!/system/bin/sh
# Modalità gioco. Il segno del Non disturbare è salvato in modo permanente,
# così viene tolto anche se la console si riavvia durante un gioco.
DNDF=$CFG/gm_dnd
gamemode_on() {
  [ "$GAMEMODE" = on ] || return
  [ -f $RUN/gm_active ] && return
  touch $RUN/gm_active
  if [ "$GAMEMODE_DND" = on ] && [ "$(sget global zen_mode)" = 0 ]; then
    cmd notification set_dnd priority >/dev/null 2>&1 && touch $DNDF
  fi
  # chiude solo app in background "sacrificabili": musica e servizi attivi restano
  am kill-all >/dev/null 2>&1
  w 1 /proc/sys/vm/compact_memory
  log "modalità gioco ON (RAM libera: $(mb_avail) MB)"
}
dnd_restore() {
  [ -f $DNDF ] || return
  # spegne il Non disturbare solo se è ancora quello attivato dal modulo
  [ "$(sget global zen_mode)" = 1 ] && cmd notification set_dnd off >/dev/null 2>&1
  rm -f $DNDF
}
gamemode_off() {
  [ -f $RUN/gm_active ] || { dnd_restore; return; }
  rm -f $RUN/gm_active
  dnd_restore
  log "modalità gioco OFF"
}
