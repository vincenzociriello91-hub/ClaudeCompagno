#!/system/bin/sh
# zram e swap su memoria interna
# ATTENZIONE: mksh (shell di Android) calcola a 32 bit. Byte > 2 GB solo con awk.
to_mb() { awk -v b="$1" 'BEGIN{ if (b ~ /^[0-9]+$/) print int(b/1048576); else print -1 }'; }

# ---------------------------------------------------------------------------
# zram. REGOLA DI SICUREZZA: la zram creata dal sistema non viene MAI spenta
# o ridimensionata (sulla Odin 2 Portal il kernel non accetta di riconfigurarla).
# Se ne serve di più, si aggiunge una seconda zram accanto a quella esistente.
# ---------------------------------------------------------------------------
ERRF=$RUN/zram_err
ultimo_errore() { e=$(tail -n1 $ERRF 2>/dev/null); echo "${e:-nessun dettaglio}"; }

swapon_pri() {  # swapon_pri dispositivo priorità
  : > $ERRF
  swapon -p $2 $1 2>>$ERRF && return 0
  [ -x /system/bin/swapon ] && /system/bin/swapon -p $2 $1 2>>$ERRF && return 0
  swapon $1 2>>$ERRF                       # senza priorità, se l'opzione non è supportata
}
mkswap_ok() {
  : > $ERRF
  mkswap $1 >/dev/null 2>>$ERRF && return 0
  [ -x /system/bin/mkswap ] && /system/bin/mkswap $1 >/dev/null 2>>$ERRF
}

zram_dev() { for d in /dev/block/zram$1 /dev/zram$1; do [ -e $d ] && { echo $d; return; }; done; }

zram_nuova() {  # zram_nuova N MB algoritmo priorità  -> 0 se attiva
  Z=/sys/block/zram$1
  # il dispositivo in /dev compare qualche istante dopo hot_add (10/11/2026: all'avvio "zram1: dispositivo non trovato")
  i=0; while D=$(zram_dev $1); [ -z "$D" ] && [ $i -lt 10 ]; do i=$((i + 1)); sleep 1; done
  [ -d $Z ] && [ -n "$D" ] || { log "zram$1: dispositivo non trovato"; return 1; }
  echo 1 > $Z/reset 2>/dev/null                       # dispositivo inattivo: azzeramento sicuro
  [ -n "$3" ] && grep -qw "$3" $Z/comp_algorithm 2>/dev/null && echo "$3" > $Z/comp_algorithm 2>/dev/null
  if ! echo "${2}M" > $Z/disksize 2>$ERRF; then log "zram$1: dimensione rifiutata ($(ultimo_errore))"; return 1; fi
  if ! mkswap_ok $D; then log "zram$1: mkswap non riuscito ($(ultimo_errore))"; echo 1 > $Z/reset 2>/dev/null; return 1; fi
  if ! swapon_pri $D $4; then log "zram$1: swapon non riuscito ($(ultimo_errore))"; echo 1 > $Z/reset 2>/dev/null; return 1; fi
  return 0
}

# MB di zram attiva in totale e priorità della prima (da /proc/swaps)
zram_totale() { awk '{n=$1; sub(".*/","",n)} n ~ /^zram[0-9]+$/ {t+=$3} END{print int(t/1024)}' /proc/swaps; }
zram_prio() { awk '{n=$1; sub(".*/","",n)} n ~ /^zram[0-9]+$/ {print $5; exit}' /proc/swaps; }
zram_attiva() { [ "$(zram_totale)" -gt 0 ] 2>/dev/null; }

apply_zram() {
  [ "$ZRAM" = default ] && return
  want=$ZRAM
  max=$(ram_mb); [ $want -gt $max ] && want=$max; [ $want -lt 512 ] && want=512
  walgo=$ZRAM_ALGO; [ "$walgo" = default ] && walgo=""
  if zram_attiva; then
    cur=$(zram_totale)
    if [ $cur -ge $((want - 64)) ]; then log "zram: ${cur} MB attivi (obiettivo ${want} MB): ok"; return; fi
    extra=$((want - cur)); [ $extra -lt 256 ] && return
    [ -r /sys/class/zram-control/hot_add ] || { log "zram: ${cur} MB del sistema, il kernel non permette di aggiungerne altra: va bene così"; return; }
    n=$(cat /sys/class/zram-control/hot_add 2>/dev/null); is_num "$n" || { log "zram: impossibile aggiungere un dispositivo: lascio ${cur} MB"; return; }
    pr=$(zram_prio); is_num "$pr" || pr=32758
    log "== zram: ${cur} MB del sistema + ${extra} MB aggiuntivi (zram$n) =="
    if zram_nuova $n $extra "$walgo" $pr; then log "zram totale: $(zram_totale) MB"
    else echo $n > /sys/class/zram-control/hot_remove 2>/dev/null; log "zram aggiuntiva non creata: resta quella del sistema (${cur} MB)"; fi
  else
    # nessuna zram attiva (spenta dal sistema o da una versione precedente del modulo)
    [ -d /sys/block/zram0 ] || { [ -r /sys/class/zram-control/hot_add ] && cat /sys/class/zram-control/hot_add >/dev/null 2>&1; }
    [ -d /sys/block/zram0 ] || { log "zram non disponibile nel kernel"; return; }
    log "== nessuna zram attiva: la creo da ${want} MB =="
    if zram_nuova 0 $want "$walgo" 32758; then log "zram attiva: $(zram_totale) MB"
    else log "il kernel non ha accettato la zram"; fi
  fi
}

# MGLRU: gestione più moderna della RAM. Il kernel della Odin ce l'ha ma spenta (odin_info del 10/11/2026: 0x0000).
# Si accende solo se il kernel la offre; il valore di prima torna con MGLRU=off, disattivando il modulo e al riavvio.
LRU=/sys/kernel/mm/lru_gen/enabled
apply_mglru() {  # apply_mglru [ripristina]
  [ -w $LRU ] || return 0
  [ -f $RUN/lru_orig ] || cat $LRU > $RUN/lru_orig
  if [ "$MGLRU" = on ] && [ "$1" != ripristina ]; then w y $LRU; else w "$(cat $RUN/lru_orig)" $LRU; fi
  log "MGLRU: $(cat $LRU)"
}

swap_active() { grep -q "^$SWAPF " /proc/swaps 2>/dev/null; }

SWAPNO=$CFG/swap_unsupported
swap_prepare() {
  swap_active && return 0
  [ -f $SWAPNO ] && return 1
  mkdir -p "${SWAPF%/*}" && chmod 700 "${SWAPF%/*}"
  have=$(to_mb "$(stat -c %s "$SWAPF" 2>/dev/null)")
  [ $have -eq $SWAPFILE_MB ] && return 0
  rm -f "$SWAPF"
  free=$(df -Pk /data 2>/dev/null | awk 'NR==2{print int($4/1024)}')
  is_num "$free" || { log "spazio libero non leggibile, swap non creato"; return 1; }
  if [ $free -lt $((SWAPFILE_MB + 8192)) ]; then
    log "spazio insufficiente per lo swap: ${free} MB liberi, servono $((SWAPFILE_MB + 8192))"; return 1
  fi
  log "creo swapfile da $SWAPFILE_MB MB..."
  if ! dd if=/dev/zero of="$SWAPF" bs=1048576 count=$SWAPFILE_MB conv=fsync 2>/dev/null; then
    rm -f "$SWAPF"; log "creazione swapfile fallita"; return 1
  fi
  chmod 600 "$SWAPF"
  mkswap "$SWAPF" >/dev/null 2>&1 || { rm -f "$SWAPF"; log "mkswap fallito"; return 1; }
  # verifica subito che il kernel accetti lo swap su file (attivazione di prova)
  if swapon_pri "$SWAPF" 5; then
    swapoff "$SWAPF" 2>/dev/null
  else
    log "il kernel non permette lo swap su file ($(ultimo_errore)): funzione disattivata, file cancellato"
    rm -f "$SWAPF"; touch $SWAPNO; return 1
  fi
}

swap_on() {
  swap_active && return 0
  swap_prepare || return 1
  # priorità bassa: usato solo quando la zram è piena
  if swapon_pri "$SWAPF" 5; then log "swap interno attivo ($SWAPFILE_MB MB)"; return 0; fi
  log "il kernel non permette lo swap su file: funzione disattivata, file cancellato"
  rm -f "$SWAPF"; touch $SWAPNO
  return 1
}

swap_off() {
  swap_active || { [ "$SWAPFILE" = off ] && [ -f "$SWAPF" ] && { rm -f "$SWAPF"; log "file swap eliminato: spazio liberato"; }; return 0; }
  if swapoff "$SWAPF" 2>/dev/null; then log "swap interno disattivato"
  else log "swap interno in uso: si disattiverà al riavvio"; fi
}

clean_ram() {  # clean_ram [notifica]
  b=$(mb_avail)
  am kill-all >/dev/null 2>&1               # solo app in background: musica e app aperte restano
  sync; echo 3 > /proc/sys/vm/drop_caches
  w 1 /proc/sys/vm/compact_memory
  sleep 1
  a=$(mb_avail); d=$((a - b)); [ $d -lt 0 ] && d=0
  msg="RAM liberata: $d MB (ora $a MB liberi su $(ram_mb) MB)"
  echo "$msg"
  log "pulizia RAM: $b -> $a MB"
  [ "$1" = notifica ] && cmd notification post -t "Odin 2 Portal" odin2_ram "$msg" >/dev/null 2>&1
  return 0
}

mem_status() {
  awk '/MemTotal/{t=$2}/MemAvailable/{a=$2}END{printf "RAM: %d MB liberi su %d MB\n",a/1024,t/1024}' /proc/meminfo
  awk 'NR>1{n=$1; sub(".*/","",n); printf "  swap %s: %d/%d MB usati\n",n,$4/1024,$3/1024}' /proc/swaps
}
