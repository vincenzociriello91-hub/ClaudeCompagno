#!/system/bin/sh
# Processo in background: app aperta, swap automatico, sessioni
GRACE=30   # secondi fuori dal gioco prima di tornare normale
SRV_EVERY=6   # giri da 5 s tra due misure del server Minecraft (30 s)

match_app() {  # stampa "pacchetto tipo profilo ventola gm hz" dell'app riconosciuta
  pk=$(top_pkgs)
  [ -n "$pk" ] || return
  if [ "$CLOUD" = auto ]; then
    for p in $pk; do is_cloud_app "$p" && { echo "$p cloud $CLOUD_PROFILE $CLOUD_FAN 1 $CLOUD_HZ"; return; }; done
    for p in $pk; do is_browser "$p" && web_cloud "$p" && { echo "$p cloud $CLOUD_PROFILE $CLOUD_FAN 1 $CLOUD_HZ"; return; }; done
  fi
  for p in $pk; do
    is_pc_app "$p" || continue
    # un'app PC con una riga sua in apps.conf tiene profilo, ventola e schermo scelti lì (es. Winlator in turbo)
    r=""; [ "$AUTO_APPS" = on ] && r=$(awk -v p="$p" '!/^#/ && $1==p { print $2, ($3==""?"auto":$3), ($4==""?"1":$4), ($5==""?"auto":$5); exit }' $CFG/apps.conf 2>/dev/null)
    echo "$p pc ${r:-$PC_PROFILE $PC_FAN 1 auto}"; return
  done
  [ "$AUTO_APPS" = on ] && [ -f $CFG/apps.conf ] || return
  echo "$pk" | awk 'NR==FNR{a[$1]=1; next}
    !/^#/ && ($1 in a) {
      t=($4=="0")?"video":"gioco"; g=($4=="")?"1":$4
      hz=$5; if (hz=="") hz=($2=="battery")?"60":"auto"
      print $1, t, $2, $3, g, hz; exit }' - $CFG/apps.conf
}

reset_state() {
  session_end 0; srv_end; srv_mode_off
  rm -f $RUN/override $RUN/cur_app $RUN/away_since $RUN/cur_modo $RUN/ripresa_srv $RUN/web_cloud $RUN/fresca
  cloud_off force; pc_off; gamemode_off; hz_restore; carica_ripristina
}

enter_app() {  # enter_app pacchetto tipo profilo ventola gm hz
  echo "$3 $4" > $RUN/override
  echo "$1" > $RUN/cur_app
  [ "$(cat $RUN/web_cloud 2>/dev/null)" = "$1" ] || rm -f $RUN/web_cloud
  [ "$2" = cloud ] && cloud_on $1
  if [ "$2" = pc ]; then pc_on; else pc_off; fi
  case $2 in cloud|pc) echo $2 > $RUN/cur_modo; esclusiva $2;; *) rm -f $RUN/cur_modo;; esac
  if [ "$5" = 1 ]; then gamemode_on; else gamemode_off; fi
  if is_num "$6"; then hz_set $6; else hz_restore; fi
  session_start $1 $2
  sh $MODDIR/apply.sh quick
  log "app: $1 -> $3, ventola $4"
}
leave_app() {
  session_end $GRACE
  rm -f $RUN/override $RUN/cur_app $RUN/away_since $RUN/cur_modo $RUN/web_cloud
  cloud_off; pc_off; gamemode_off; hz_restore
  sh $MODDIR/apply.sh quick
  log "app chiusa: profilo normale"
}

watcher() {
  SUP=$$   # nella subshell $$ è il PID del supervisore
  load_conf
  [ "$SWAPFILE" = auto ] && swap_prepare
  n=0; t=0
  while true; do
    [ "$(cat $RUN/watch.pid 2>/dev/null)" = "$SUP" ] || exit 0
    # modulo disattivato o rimosso da Magisk: ripristina e termina
    if [ -f $MODDIR/disable ] || [ -f $MODDIR/remove ]; then
      reset_state; sh $MODDIR/apply.sh restore; exit 0
    fi
    load_conf
    if [ "$SWAPFILE" != auto ] && [ "$CLOUD" != auto ] && [ "$AUTO_APPS" != on ] && [ "$SERVER_MODE" != auto ] && [ "$PC" != auto ]; then
      [ -f $RUN/cur_app ] && { reset_state; sh $MODDIR/apply.sh quick; }
      exit 0
    fi
    # swap automatico
    if [ "$SWAPFILE" = auto ] && [ ! -f $SWAPNO ] && ! swap_active; then
      sf=$(awk '/SwapFree/{v=int($2/1024)} END{print v+0}' /proc/meminfo)
      [ $(( $(mb_avail) + sf )) -lt $SWAP_THRESHOLD_MB ] && { log "RAM quasi piena: attivo swap"; swap_on; }
    fi
    # ogni 30 s: se il sistema ha cambiato le frequenze, riapplica il profilo
    t=$((t + 1))
    if [ $((t % 6)) = 0 ] && cpu_reassert; then
      [ -f $RUN/drift_logged ] || { log "frequenze cambiate dal sistema: profilo ripristinato (messaggio mostrato una volta)"; touch $RUN/drift_logged; }
    fi
    # server Minecraft acceso (Termux, anche a schermo spento): consumo misurato ogni 30 s
    [ $((t % SRV_EVERY)) = 0 ] && srv_tick
    remoto_tick   # comandi dal pannello (assistente remoto)
    ponte_tick    # ponte veloce con Claude (v4.29): processo acceso e tenuto vivo
    w2_tick       # doppio Wi-Fi (v4.28): acceso dopo l'avvio e rifatto se la rete principale cambia banda
    # app riconosciuta in primo piano
    m=$(match_app); cur=$(cat $RUN/cur_app 2>/dev/null)
    if [ -n "$m" ]; then
      rm -f $RUN/away_since
      set -- $m
      if [ "$1" != "$cur" ]; then
        [ -n "$cur" ] && { session_end 0; cloud_off; }
        enter_app $1 $2 $3 $4 $5 $6
      fi
      n=$((n + 1)); [ $((n % 3)) = 0 ] && session_tick
      [ -f $RUN/cloud_active ] && net_mon_tick
    elif [ -n "$cur" ]; then
      now=$(date +%s)
      [ -f $RUN/away_since ] || echo $now > $RUN/away_since
      a=$(cat $RUN/away_since); is_num "$a" || a=$now
      [ $((now - a)) -ge $GRACE ] && leave_app
    fi
    sleep 5
  done
}
