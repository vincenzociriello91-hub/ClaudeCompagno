#!/system/bin/sh
# Rete: valori sempre attivi + modalità cloud gaming
apply_net_base() {
  # buffer più grandi per lo streaming UDP (video del cloud gaming):
  # assorbono i picchi senza scartare pacchetti
  w 16777216 /proc/sys/net/core/rmem_max
  w 4194304  /proc/sys/net/core/wmem_max
  w 1048576  /proc/sys/net/core/rmem_default
  w 10000    /proc/sys/net/core/netdev_max_backlog
  w 16384    /proc/sys/net/ipv4/udp_rmem_min
  w 16384    /proc/sys/net/ipv4/udp_wmem_min
  grep -qw bbr /proc/sys/net/ipv4/tcp_available_congestion_control 2>/dev/null && w bbr /proc/sys/net/ipv4/tcp_congestion_control
  w 0 /proc/sys/net/ipv4/tcp_slow_start_after_idle
  w 1 /proc/sys/net/ipv4/tcp_mtu_probing
}

# app in primo piano esatta (solo su richiesta: comando pesante)
foreground_app() {
  dumpsys activity activities 2>/dev/null | grep -m1 -E 'topResumedActivity|mResumedActivity' \
    | sed -E 's/.* ([a-zA-Z0-9_.]+)\/.*/\1/'
}
# pacchetti nel gruppo "top-app" del sistema: lettura leggerissima
top_pkgs() {
  f=/dev/cpuset/top-app/cgroup.procs
  if [ -r $f ]; then
    for p in $(cat $f); do
      c=$(tr '\0' '\n' < /proc/$p/cmdline 2>/dev/null | head -n1); [ -n "$c" ] && echo "${c%%:*}"
    done | sort -u
  else
    foreground_app
  fi
}
is_cloud_app() { case " $CLOUD_APPS " in *" $1 "*) return 0;; esac; return 1; }

# --- Cloud gaming dentro Chrome (v4.18): Amazon Luna su Android non ha un'app, è un sito o una web app di Chrome.
# Dal sistema si vede solo "Chrome a schermo": l'indirizzo lo legge l'app Diario Odin, che scrive in diretta
# (ogni 5 s) ciò che compare a schermo. Qui si guardano le ultime righe dall'ultimo cambio di app:
#  - scheda di Chrome: una riga di testo che è solo un indirizzo e comincia con un sito di CLOUD_WEB;
#  - web app installata (org.chromium.webapk.*): conta il sito scritto nel suo pacchetto, non il testo a schermo
#    (una chat che nomina il sito non deve accendere la modalità cloud).
# shortcut: una volta riconosciuto vale finché Chrome resta a schermo, anche se cambi scheda; da affinare se dà fastidio.
DLOG=/data/data/com.vincenzo.diarioodin/files/sessione.log
is_browser() { case $1 in com.android.chrome|com.chrome.*|org.chromium.webapk.*) return 0;; esac; return 1; }
webapk_cloud() {  # la web app installata punta a un sito di CLOUD_WEB? (risposta tenuta fino al riavvio)
  is_pkg "$1" || return 1
  f=$RUN/webapk_$1
  if [ ! -f $f ]; then
    d=$(dumpsys package $1 2>/dev/null); r=no
    for w in $CLOUD_WEB; do case $d in *"$w"*) r=si;; esac; done
    echo $r > $f
  fi
  [ "$(cat $f)" = si ]
}
web_cloud() {  # web_cloud pacchetto_del_browser -> 0 se a schermo c'è un sito di cloud gaming
  [ -n "$CLOUD_WEB" ] || return 1
  [ "$(cat $RUN/web_cloud 2>/dev/null)" = "$1" ] && return 0
  [ -r $DLOG ] || return 1
  r=$(tail -n 80 $DLOG 2>/dev/null | awk -v siti="$CLOUD_WEB" '
    /\] APP +/ { hit = 0; wa = ""; for (i = 1; i < NF; i++) if ($i == "APP") { if ($(i+1) ~ /^org\.chromium\.webapk\./) wa = $(i+1); break }; next }
    /\] (SCHERMATA|TESTO) +/ && wa == "" {
      t = $0; sub(/^[^|]*\| /, "", t); n = split(t, riga, " · "); m = split(siti, s, " ")
      for (i = 1; i <= n; i++) { x = riga[i]; sub(/^https?:\/\//, "", x); sub(/^www\./, "", x); if (x ~ / /) continue
        for (j = 1; j <= m; j++) if (index(x, s[j]) == 1) hit = 1 }
    }
    END { if (wa != "") print "webapk " wa; else if (hit) print "sito" }')
  case $r in
    sito) ;;
    "webapk "*) webapk_cloud "${r#webapk }" || return 1;;
    *) return 1;;
  esac
  echo $1 > $RUN/web_cloud
}

pkg_uid() {
  is_pkg "$1" || return
  u=$(cmd package list packages -U "$1" 2>/dev/null | awk -v p="package:$1" '$1==p{sub("uid:","",$2); sub(",.*","",$2); print $2; exit}')
  is_num "$u" && [ $u -ge 10000 ] && echo $u
}

# --- Priorità del traffico (QoS) ---
# I pacchetti dell'app ricevono il marchio DSCP "EF": il Wi-Fi (WMM) li
# mette nella coda "voce", trasmessa per prima. Agisce su comandi e
# controller che partono dalla console; molti router lo rispettano anche
# nel tragitto inverso. Catena separata: le regole di Android non si toccano.
QCH=odin2_qos
qos_on() {  # qos_on pacchetto...   (senza argomenti: tutte le app cloud installate)
  [ "$CLOUD_QOS" = on ] || return
  pl="$*"; [ -n "$pl" ] || pl=$CLOUD_APPS
  uids=""; for p in $pl; do u=$(pkg_uid $p); [ -n "$u" ] && uids="$uids $u"; done
  [ -n "$uids" ] || { log "QoS: nessuna app cloud installata trovata"; return; }
  okq=0
  for ipt in iptables ip6tables; do
    command -v $ipt >/dev/null 2>&1 || continue
    $ipt -w -t mangle -N $QCH 2>/dev/null
    $ipt -w -t mangle -F $QCH 2>/dev/null
    $ipt -w -t mangle -C OUTPUT -j $QCH 2>/dev/null || $ipt -w -t mangle -I OUTPUT -j $QCH 2>/dev/null
    for u in $uids; do
      $ipt -w -t mangle -A $QCH -m owner --uid-owner $u -j DSCP --set-dscp-class EF 2>/dev/null && okq=1
    done
  done
  if [ $okq = 1 ]; then touch $RUN/qos_active; log "QoS: priorità massima al traffico di:$( for p in $pl; do [ -n "$(pkg_uid $p)" ] && printf ' %s' $p; done)"
  else qos_off; log "QoS: non supportato dal kernel, salto"; fi
}
qos_off() {
  for ipt in iptables ip6tables; do
    command -v $ipt >/dev/null 2>&1 || continue
    while $ipt -w -t mangle -D OUTPUT -j $QCH 2>/dev/null; do :; done
    $ipt -w -t mangle -F $QCH 2>/dev/null
    $ipt -w -t mangle -X $QCH 2>/dev/null
  done
  rm -f $RUN/qos_active
}

# --- Esclusione dal risparmio energetico ---
noidle_on() {
  [ "$CLOUD_NOIDLE" = on ] || return
  if cmd deviceidle whitelist 2>/dev/null | grep -q ",$1,"; then return; fi   # già esclusa dall'utente
  cmd deviceidle whitelist +$1 >/dev/null 2>&1 && echo $1 > $CFG/noidle_pkg
  am set-standby-bucket $1 active >/dev/null 2>&1
}
noidle_off() {  # rimuove solo ciò che ha aggiunto il modulo (segno permanente: vale anche dopo un riavvio)
  p=$(cat $CFG/noidle_pkg 2>/dev/null); is_pkg "$p" || { rm -f $CFG/noidle_pkg; return; }
  cmd deviceidle whitelist -$p >/dev/null 2>&1
  rm -f $CFG/noidle_pkg
}

# --- Monitor della rete durante la sessione (per il report) ---
net_mon_start() {
  gw=$(ip route get 1.1.1.1 2>/dev/null | grep -oE 'via [0-9.]+' | cut -d' ' -f2)
  echo "$gw" > $RUN/mon_gw
  echo "0 0 0 0" > $RUN/mon     # inviati persi picchi somma_ms
}
net_mon_tick() {
  gw=$(cat $RUN/mon_gw 2>/dev/null); [ -n "$gw" ] || return
  read -r sent lost spk sum < $RUN/mon 2>/dev/null
  is_num "$sent" || { sent=0; lost=0; spk=0; sum=0; }
  t=$(ping -c 1 -W 1 $gw 2>/dev/null | grep -oE 'time[=<][0-9.]+' | head -n1 | grep -oE '[0-9]+' | head -n1)
  sent=$((sent + 1))
  if is_num "$t"; then
    sum=$((sum + t)); [ $t -ge 40 ] && spk=$((spk + 1))
  else lost=$((lost + 1)); fi
  echo "$sent $lost $spk $sum" > $RUN/mon
}
net_mon_summary() {
  read -r sent lost spk sum < $RUN/mon 2>/dev/null
  is_num "$sent" && [ $sent -gt 0 ] || return
  rec=$((sent - lost)); [ $rec -gt 0 ] && avg=$((sum / rec)) || avg="-"
  echo "Wi-Fi: ping medio ${avg} ms, picchi $spk, persi $((lost * 100 / sent))% su $sent controlli"
}

cloud_on() {  # cloud_on pacchetto
  [ -f $RUN/cloud_active ] && return
  touch $RUN/cloud_active
  # Wi-Fi in bassa latenza: niente risparmio energetico sulla scheda
  cmd wifi force-low-latency-mode enabled >/dev/null 2>&1
  if [ -n "$1" ] && [ -n "$(pkg_uid $1)" ]; then qos_on $1; noidle_on $1; else qos_on; fi
  net_mon_start
  log "== Cloud gaming ON ($1) =="
}
cloud_off() {  # "force" = spegni anche se impostato su on
  [ -f $RUN/cloud_active ] || { noidle_off; return; }
  [ "$CLOUD" = on ] && [ "$1" != force ] && return
  rm -f $RUN/cloud_active
  cmd wifi force-low-latency-mode disabled >/dev/null 2>&1
  qos_off; noidle_off
  log "== Cloud gaming OFF =="
}
