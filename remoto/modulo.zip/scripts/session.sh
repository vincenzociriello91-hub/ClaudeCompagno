#!/system/bin/sh
# Report di fine sessione
SESS=$CFG/sessions.log
batt() { b=$(cat /sys/class/power_supply/battery/capacity 2>/dev/null); is_num "$b" && echo $b || echo 0; }
upd() { is_num "$2" || return; o=$(cat $RUN/s_$1 2>/dev/null); is_num "$o" || o=0; [ $2 -gt $o ] && echo $2 > $RUN/s_$1; }

# Report automatico a fine partita: file in Download + notifica (ultimi 30 tenuti)
REPD=/sdcard/Download/Odin2_report
report_write() {  # report_write riga pacchetto
  [ "$REPORT" = on ] || return 0
  mkdir -p $REPD 2>/dev/null || return 0
  f=$REPD/$(date +%Y%m%d_%H%M)_${2##*.}.txt
  {
    echo "=== REPORT PARTITA ==="
    echo "$1" | awk -F' [|] ' '{for (i=1; i<=NF; i++) print $i}'
    echo; echo "=== STATO A FINE PARTITA ==="
    fan_status; mem_status
    echo; echo "=== ULTIME RIGHE DEL REGISTRO ==="
    tail -n 25 $LOG
  } > $f 2>&1
  # solo i report di partita (AAAAMMGG_HHMM_app.txt): gli altri file della cartella restano
  ls -t $REPD/[0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]_[0-9][0-9][0-9][0-9]_*.txt 2>/dev/null | tail -n +31 | while read -r x; do rm -f "$x"; done
  cmd notification post -t "Odin 2 Portal" odin2_report "Report salvato: Download/Odin2_report/${f##*/}" >/dev/null 2>&1
  return 0
}

session_start() {  # session_start pacchetto tipo
  for c in /sys/class/thermal/cooling_device*; do
    case $(cat $c/type 2>/dev/null) in *cpu*|*gpu*|*kgsl*) echo $c;; esac
  done > $RUN/thr_devs
  rm -f $RUN/s_*
  echo "$1 $2 $(date +%s) $(batt)" > $RUN/session
}
session_tick() {
  [ -f $RUN/session ] || return
  upd cpu "$(zone_max cpu-)"; upd gpu "$(zone_max gpuss-)"
  bt=$(cat /sys/class/power_supply/battery/temp 2>/dev/null); is_num "$bt" && upd bat $((bt / 10))
  [ -f $RUN/s_thr ] && return
  for c in $(cat $RUN/thr_devs 2>/dev/null); do
    s=$(cat $c/cur_state 2>/dev/null); is_num "$s" && [ $s -gt 0 ] && { touch $RUN/s_thr; break; }
  done
}
session_end() {  # session_end secondi_da_togliere
  [ -f $RUN/session ] || return
  read -r pkg typ start b0 < $RUN/session
  rm -f $RUN/session
  is_num "$start" || return
  is_num "$b0" || b0=$(batt)
  off=${1:-0}; is_num "$off" || off=0
  min=$(( ($(date +%s) - start - off) / 60 ))
  [ $min -lt 2 ] && return
  d=$(( b0 - $(batt) ))
  if [ $d -lt 0 ]; then bat="in carica"; else bat="batteria -${d}% (~$(( d * 60 / (min > 0 ? min : 1) ))%/h)"; fi
  [ -f $RUN/s_thr ] && thr="sì" || thr="no"
  when=$(date -d @$start '+%d/%m %H:%M' 2>/dev/null) || when=$(date '+%d/%m %H:%M')
  nm=""; [ "$typ" = cloud ] && nm=" | $(net_mon_summary)"
  line="$when | $pkg ($typ) | $min min | $bat$nm | CPU max $(cat $RUN/s_cpu 2>/dev/null || echo ?)°C | GPU max $(cat $RUN/s_gpu 2>/dev/null || echo ?)°C | batt. max $(cat $RUN/s_bat 2>/dev/null || echo ?)°C | rallentamenti termici: $thr"
  echo "$line" >> $SESS
  tail -n 100 $SESS > $SESS.tmp && mv $SESS.tmp $SESS
  report_write "$line" "$pkg"
  log "sessione: $line"
}

# --- Server Minecraft (Claude Compagno in Termux, di solito a schermo spento) ---
# Non è un'app in primo piano, quindi la sessione di gioco non lo vede: qui si misura il consumo vero dalla batteria
# (corrente x tensione) ogni 30 s, separando "solo il bot" da "giocatori connessi" (letti dal registro del server).
MCROOT=/data/data/com.termux/files/usr/var/lib/proot-distro/installed-rootfs/debian/root/claudemc
MCLOG=$MCROOT/log
srv_on() { pgrep -f bedrock_server >/dev/null 2>&1; }
srv_avvisa() { cmd notification post -t "Odin 2 Portal" odin2_server "$1" >/dev/null 2>&1; log "server: $1"; }
srv_players() {
  f=$(ls -t $MCLOG/server_*.log 2>/dev/null | head -1)
  [ -n "$f" ] || { echo 0; return; }
  awk '/Server started/{n=0} /Player connected:/{n++} /Player disconnected:/{n--} END{print (n>0?n:0)}' "$f"
}
srv_max() { is_num "$2" || return; o=$(cat $RUN/srv_$1 2>/dev/null); is_num "$o" || o=0; [ $2 -gt $o ] && echo $2 > $RUN/srv_$1; }
# Modalità server: Termux fuori dal risparmio energetico, Wi-Fi senza risparmio, profilo server (apply.sh legge srv_mode)
srv_mode_on() {
  touch $RUN/srv_mode
  if ! cmd deviceidle whitelist 2>/dev/null | grep -q ",com.termux,"; then
    cmd deviceidle whitelist +com.termux >/dev/null 2>&1 && touch $CFG/noidle_termux
  fi
  cmd wifi force-low-latency-mode enabled >/dev/null 2>&1
  # schermo: si spegne da solo dopo 1 minuto senza tocchi (il valore di prima torna quando il server si spegne)
  if [ "$SERVER_SCREEN_S" -gt 0 ] 2>/dev/null && [ ! -f $CFG/screen_orig ]; then
    o=$(sget system screen_off_timeout); is_num "$o" && { echo $o > $CFG/screen_orig; sput system screen_off_timeout $((SERVER_SCREEN_S * 1000)); }
  fi
  log "server Minecraft acceso: modalità server"
}

# --- Cose che la modalità server fa ogni 30 s ---
srv_pids() { pgrep -f bedrock_server 2>/dev/null; }
srv_proteggi() {  # Android non lo chiude mai per liberare RAM; core medi e grande (3-7), priorità alta
  for p in $(srv_pids); do
    is_num "$p" || continue
    [ "$(cat /proc/$p/oom_score_adj 2>/dev/null)" = -1000 ] && continue
    echo -1000 > /proc/$p/oom_score_adj 2>/dev/null
    taskset -a -p f8 $p >/dev/null 2>&1
    renice -n -10 -p $p >/dev/null 2>&1
    log "server Minecraft (pid $p): protetto dalla chiusura, core 3-7, priorità alta"
  done
}
srv_vivo() {  # registro fermo da 5 minuti dopo l'avvio completo = bloccato: lo chiude e avvia.sh lo riavvia (crash)
  [ -f $RUN/srv_pausa ] && return 0   # in pausa per il calore il registro è fermo apposta
  f=$(ls -t $MCLOG/server_*.log 2>/dev/null | head -1)
  [ -n "$f" ] && grep -q "Server started" "$f" 2>/dev/null || return 0
  m=$(stat -c %Y "$f" 2>/dev/null); is_num "$m" || return 0
  if [ $(( $(date +%s) - m )) -lt 300 ]; then rm -f $RUN/srv_fermo; return 0; fi
  [ -f $RUN/srv_fermo ] && return 0
  touch $RUN/srv_fermo
  for p in $(srv_pids); do is_num "$p" && kill -9 $p 2>/dev/null; done
  srv_avvisa "Server Minecraft bloccato da 5 minuti: chiuso, riparte da solo"
}
srv_batteria() {  # sotto la soglia senza caricatore: salva il mondo e ferma il server in modo pulito (niente mondo rovinato)
  case $(cat /sys/class/power_supply/battery/status 2>/dev/null) in
    Discharging|"Not charging") ;;
    *) rm -f $RUN/srv_batt_stop; return 0;;
  esac
  [ -f $CFG/input_suspend_on ] && return 0       # è il limite di carica a staccare la corrente: si riattacca al 60%
  b=$(batt); [ $b -gt 0 ] && [ $b -le $SERVER_BATT_STOP ] && [ ! -f $RUN/srv_batt_stop ] || return 0
  touch $RUN/srv_batt_stop
  srv_pausa_off   # un server in pausa non leggerebbe lo stop: lo si riprende per salvare il mondo
  timeout 5 sh -c "echo stop > $MCROOT/console" 2>/dev/null
  srv_avvisa "Batteria al $b%: mondo salvato e server Minecraft fermato. Attacca il caricatore e riaccendilo con mc-avvia"
}
srv_carica() {  # Odin sempre attaccata: batteria tra 60% e 80% invece che al 100% (dura molto di più)
  [ "$SERVER_CHARGE_LIMIT" = on ] || return 0
  B=/sys/class/power_supply/battery
  if [ -w $B/charge_control_end_threshold ]; then
    [ -f $CFG/charge_orig ] || cat $B/charge_control_end_threshold > $CFG/charge_orig 2>/dev/null
    [ "$(cat $B/charge_control_end_threshold)" = 80 ] || w 80 $B/charge_control_end_threshold
    return 0
  fi
  if [ ! -w $B/input_suspend ]; then
    [ -f $RUN/srv_nocarica ] || { touch $RUN/srv_nocarica; log "limite di carica: questo kernel non lo permette"; }
    return 0
  fi
  b=$(batt)
  if [ $b -ge 80 ] && [ "$(cat $B/input_suspend)" != 1 ]; then
    echo 1 > $B/input_suspend && touch $CFG/input_suspend_on && log "limite di carica: batteria al $b%, corrente staccata fino al 60%"
  elif [ $b -le 60 ] && [ -f $CFG/input_suspend_on ]; then
    echo 0 > $B/input_suspend; rm -f $CFG/input_suspend_on; log "limite di carica: batteria al $b%, ricarico fino all'80%"
  fi
}
srv_carica_off() {  # rimette la carica normale (anche dopo un riavvio o se il modulo viene disattivato)
  B=/sys/class/power_supply/battery
  [ -f $CFG/input_suspend_on ] && { echo 0 > $B/input_suspend 2>/dev/null; rm -f $CFG/input_suspend_on; }
  [ -f $CFG/charge_orig ] && { o=$(cat $CFG/charge_orig); is_num "$o" && w $o $B/charge_control_end_threshold; rm -f $CFG/charge_orig; }
  return 0
}
srv_ip() {  # il router ha dato un indirizzo nuovo alla Odin: notifica con quello giusto
  ip=$(ip -4 -o addr show wlan0 2>/dev/null | awk '{sub("/.*", "", $4); print $4; exit}')
  [ -n "$ip" ] || return 0
  o=$(cat $CFG/srv_ip 2>/dev/null); [ "$ip" = "$o" ] && return 0
  echo $ip > $CFG/srv_ip
  [ -n "$o" ] && srv_avvisa "Il server ha un indirizzo nuovo: $ip (prima $o). Pannello: http://$ip:8080"
  return 0
}
srv_pausa_off() {  # riprende il server messo in pausa per il calore (mai lasciarlo fermo)
  [ -f $RUN/srv_pausa ] || return 0
  for p in $(srv_pids); do is_num "$p" && kill -CONT $p 2>/dev/null; done
  rm -f $RUN/srv_pausa $RUN/srv_pausa_n
}
srv_calore() {  # CPU oltre la soglia: profilo battery e ventola sport finché non scende di 10 °C
  t=$(zone_max cpu-); is_num "$t" || return 0
  # protezione: CPU >= SERVER_PAUSE per 3 controlli di fila (90 s) = server in pausa finché non scende di 15 °C
  if [ -f $RUN/srv_pausa ]; then
    if [ $t -le $((SERVER_PAUSE - 15)) ]; then
      srv_pausa_off; srv_avvisa "Odin raffreddata (CPU $t °C): server ripartito"
    else
      for p in $(srv_pids); do is_num "$p" && kill -STOP $p 2>/dev/null; done   # anche un processo nuovo resta fermo
    fi
    return 0
  fi
  if [ $t -ge $SERVER_PAUSE ]; then
    n=$(cat $RUN/srv_pausa_n 2>/dev/null); is_num "$n" || n=0; n=$((n + 1)); echo $n > $RUN/srv_pausa_n
    if [ $n -ge 3 ]; then
      touch $RUN/srv_pausa
      for p in $(srv_pids); do is_num "$p" && kill -STOP $p 2>/dev/null; done
      srv_avvisa "Odin troppo calda (CPU $t °C da 90 secondi): server in pausa per proteggerla, riparte da solo sotto $((SERVER_PAUSE - 15)) °C"
      return 0
    fi
  else rm -f $RUN/srv_pausa_n; fi
  if [ $t -ge $SERVER_HOT ] && [ ! -f $RUN/srv_caldo ]; then
    touch $RUN/srv_caldo; sh $MODDIR/apply.sh quick
    srv_avvisa "Odin calda (CPU $t °C): server più leggero e ventola più forte finché non si raffredda"
  elif [ $t -le $((SERVER_HOT - 10)) ] && [ -f $RUN/srv_caldo ]; then
    rm -f $RUN/srv_caldo; sh $MODDIR/apply.sh quick; log "server: temperatura tornata normale ($t °C)"
  fi
  return 0
}
srv_mode_off() {  # toglie solo ciò che ha messo il modulo (segni permanenti: vale anche dopo un riavvio)
  srv_pausa_off
  [ -f $CFG/noidle_termux ] && { cmd deviceidle whitelist -com.termux >/dev/null 2>&1; rm -f $CFG/noidle_termux; }
  srv_carica_off
  if [ -f $CFG/screen_orig ]; then o=$(cat $CFG/screen_orig); is_num "$o" && sput system screen_off_timeout $o; rm -f $CFG/screen_orig; fi
  [ -f $RUN/srv_mode ] || return 0
  rm -f $RUN/srv_mode $RUN/srv_caldo $RUN/srv_fermo $RUN/srv_batt_stop
  [ -f $RUN/cloud_active ] || cmd wifi force-low-latency-mode disabled >/dev/null 2>&1
  log "server Minecraft spento: modalità server finita"
}
# stato della Odin per il pannello del server: Termux non può leggere batteria e uptime (SELinux), il modulo sì.
# File fuori da Odin2_report (non va su Drive: cambia ogni 30 s), sostituito in un colpo solo.
SRV_STATO=/sdcard/Download/.odin_stato
srv_stato() {
  B=/sys/class/power_supply/battery
  { echo "batteria=$(cat $B/capacity 2>/dev/null)"
    echo "stato=$(cat $B/status 2>/dev/null)"
    echo "temp_batteria=$(cat $B/temp 2>/dev/null)"
    echo "corrente_ua=$(cat $B/current_now 2>/dev/null)"
    echo "tensione_uv=$(cat $B/voltage_now 2>/dev/null)"
    echo "temp_cpu=$(zone_max cpu-)"
    echo "temp_gpu=$(zone_max gpuss-)"
    CD=$(fan_cdev); [ -n "$CD" ] && { echo "ventola=$(cat /sys/class/thermal/$CD/cur_state 2>/dev/null)"; echo "ventola_max=$(cat /sys/class/thermal/$CD/max_state 2>/dev/null)"; }
    echo "pausa_calore=$([ -f $RUN/srv_pausa ] && echo 1 || echo 0)"
    echo "carica_limite=$([ -f $CFG/input_suspend_on ] && echo 1 || echo 0)"
    echo "uptime=$(cut -d' ' -f1 /proc/uptime 2>/dev/null)"
    echo "ora=$(date +%s)"
  } > $SRV_STATO.tmp 2>/dev/null && mv -f $SRV_STATO.tmp $SRV_STATO 2>/dev/null
}

srv_tick() {  # chiamata dal watcher ogni 30 s
  # (il segno non si chiama srv_*: srv_end cancella tutti i file srv_*) server fermato dal modulo per un gioco: riparte quando il gioco non è più a schermo e il server è davvero spento
  if [ -f $RUN/ripresa_srv ] && [ ! -f $RUN/cur_modo ] && ! srv_on; then
    rm -f $RUN/ripresa_srv; [ "$ESCLUSIVE" = on ] && { log "gioco chiuso: riaccendo il server Minecraft"; rem_server; }
  fi
  if srv_on; then
    [ "$SERVER_MODE" = auto ] && [ ! -f $RUN/srv_mode ] && { srv_mode_on; esclusiva server; sh $MODDIR/apply.sh quick; }
  elif [ -f $RUN/srv_mode ]; then
    srv_mode_off; sh $MODDIR/apply.sh quick
  fi
  if [ -f $RUN/srv_mode ]; then srv_proteggi; srv_vivo; srv_batteria; srv_carica; srv_ip; srv_calore; fi
  [ "$REPORT" = on ] || return 0
  if ! srv_on; then [ -f $RUN/srv ] && srv_end; return 0; fi
  [ -f $RUN/srv ] || { rm -f $RUN/srv_*; echo "$(date +%s) $(batt) $(cat /sys/class/power_supply/battery/charge_counter 2>/dev/null)" > $RUN/srv; }
  B=/sys/class/power_supply/battery
  srv_stato
  srv_max cpu "$(zone_max cpu-)"
  bt=$(cat $B/temp 2>/dev/null); is_num "$bt" && srv_max bat $((bt / 10))
  k=bot; p=$(srv_players); is_num "$p" && [ $p -gt 0 ] && k=online
  case $(cat $B/status 2>/dev/null) in
    Discharging|"Not charging") ;;
    *) echo 1 >> $RUN/srv_carica; return 0;;  # sotto carica la corrente è quella che entra, non il consumo
  esac
  # mW = |µA| x µV / 1e9 con awk (mksh calcola a 32 bit); valori piccoli = il kernel li dà in mA / mV
  awk -v i="$(cat $B/current_now 2>/dev/null)" -v v="$(cat $B/voltage_now 2>/dev/null)" 'BEGIN{
    if (i !~ /^-?[0-9]+$/ || v !~ /^[0-9]+$/) exit; if (i < 0) i = -i; if (i < 20000) i *= 1000; if (v < 20000) v *= 1000
    w = i * v / 1e9; if (w > 0 && w < 30000) printf "%d\n", w }' >> $RUN/srv_$k
  # ogni 10 minuti un riepilogo aggiornato, così si vede anche mentre il server è acceso
  n=$(cat $RUN/srv_n 2>/dev/null); is_num "$n" || n=0; n=$((n + 1)); echo $n > $RUN/srv_n
  [ $((n % 20)) = 0 ] && srv_summary > $REPD/consumo_server.txt 2>/dev/null
  return 0
}
srv_summary() {  # testo del riepilogo: durate stimate da 100% a 0% con la capacità reale della batteria
  read -r start b0 cc0 < $RUN/srv
  min=$(( ($(date +%s) - start) / 60 )); d=$(( b0 - $(batt) ))
  cap=$(cat /sys/class/power_supply/battery/charge_full 2>/dev/null)
  when=$(date -d @$start '+%d/%m %H:%M' 2>/dev/null) || when=$(date '+%d/%m %H:%M')
  # contatore di carica (µAh): quanta carica è uscita davvero. Le misure istantanee la sovrastimano (sulla Odin vera
  # 1.69 W misurati contro circa 1.2 W dal calo della batteria): il modulo che misura sveglia la CPU proprio in quell'istante
  awk -v when="$when" -v min="$min" -v d="$d" -v cap="$cap" -v cc0="$cc0" -v cc1="$(cat /sys/class/power_supply/battery/charge_counter 2>/dev/null)" -v nc="$(wc -l 2>/dev/null < $RUN/srv_carica)" \
      -v cpu="$(cat $RUN/srv_cpu 2>/dev/null)" -v bat="$(cat $RUN/srv_bat 2>/dev/null)" \
      -v fb="$RUN/srv_bot" -v fo="$RUN/srv_online" 'BEGIN{
    wh = (cap ~ /^[0-9]+$/ && cap > 0) ? cap / 1e6 * 3.87 : 8 * 3.87; if (cap > 0 && cap < 100000) wh = cap / 1e3 * 3.87
    while ((getline x < fb) > 0) { sb += x; nb++ }
    while ((getline x < fo) > 0) { so += x; no++ }
    print "=== CONSUMO SERVER MINECRAFT ==="
    printf "Inizio: %s | durata %d min | batteria %s\n", when, min, (d >= 0 ? "-" d "%" : "in carica")
    printf "Capacità batteria usata per le stime: %.1f Wh\n", wh
    if (cc0 ~ /^[0-9]+$/ && cc1 ~ /^[0-9]+$/ && cc0 > cc1 && min >= 10 && nc + 0 == 0) {
      wr = (cc0 - cc1) / 1e6 * 3.87 / (min / 60)
      printf "CONSUMO REALE (contatore di carica, %d min): %.2f W -> da 100%% a 0%% circa %.1f ore\n", min, wr, wh / wr
    } else if (cc0 ~ /^[0-9]+$/) print "Consumo reale: servono almeno 10 minuti a batteria senza caricatore"
    print "Misure istantanee (più alte del reale, servono a confrontare bot e giocatori):"
    riga("Solo il bot (nessun giocatore)", sb, nb); riga("Giocatori connessi", so, no)
    if (nb + no > 0) riga("Media di tutta la sessione", sb + so, nb + no)
    if (nc + 0 > 0) printf "Misure saltate perché in carica: %d (stacca il caricatore per misurare)\n", nc
    printf "Temperature massime: CPU %s°C, batteria %s°C\n", (cpu == "" ? "?" : cpu), (bat == "" ? "?" : bat)
  }
  function riga(t, s, n) {
    if (!n) { printf "%s: nessuna misura a batteria\n", t; return }
    w = s / n / 1000; printf "%s: %.2f W in media su %d misure -> da 100%% a 0%% circa %.1f ore\n", t, w, n, wh / w }'
}
srv_end() {
  [ -f $RUN/srv ] || return 0
  s=$(srv_summary)
  rm -f $RUN/srv $RUN/srv_* $SRV_STATO
  mkdir -p $REPD 2>/dev/null
  echo "$s" > $REPD/consumo_server.txt
  f=$REPD/$(date +%Y%m%d_%H%M)_minecraft_server.txt
  { echo "$s"; echo; echo "=== STATO A FINE SESSIONE ==="; fan_status; mem_status; } > $f 2>&1
  echo "$(date '+%d/%m %H:%M') | server Minecraft | $(echo "$s" | grep -m1 'Media' || echo 'nessuna misura a batteria')" >> $SESS
  cmd notification post -t "Odin 2 Portal" odin2_report "Consumo server Minecraft: Download/Odin2_report/${f##*/}" >/dev/null 2>&1
  log "server Minecraft spento: report ${f##*/}"
}
