#!/system/bin/sh
# Ponte veloce (v4.29): Claude manda un comando dal connettore di claude.ai, la Odin lo prende in pochi secondi.
# Gira in un processo a sé, acceso e tenuto vivo dal watcher (ponte_tick). Richiesta lunga al worker Cloudflare
# "odin-ponte" (fino a 50 s, poi si ripete): nessun traffico quando non arriva niente, a parte la richiesta stessa.
# Sicurezza: il gettone è sha256("ponte|<chiave>"), con la stessa chiave dei comandi firmati ($CFG/remoto.key, solo
# sulla Odin e su Drive). Il worker conosce solo l'impronta del gettone. Chi non ha il percorso segreto del connettore
# o il gettone non può mettere comandi in coda né leggerli.
MODDIR=${MODDIR:-/data/adb/modules/odin2tweaks}
. $MODDIR/scripts/common.sh
PONTE_URL_PRED=https://odin-ponte.vincenzociriello91.workers.dev
PONTE_MAX=600   # secondi massimi per un comando (oltre: fermato)

ponte_url() { u=$(cat $CFG/ponte_url 2>/dev/null); echo "${u:-$PONTE_URL_PRED}"; }

ponte_esegui() {  # $1 file con "id\nscript": esegue e rimanda l'uscita (al massimo 60 KB)
  id=$(head -n 1 "$1" | tr -cd '0-9'); is_num "$id" || return 1
  s=$RUN/ponte_script.sh; o=$RUN/ponte_uscita.txt
  tail -n +2 "$1" > $s
  timeout $PONTE_MAX sh $s </dev/null > $o 2>&1; e=$?
  [ $e = 124 ] && echo "--- fermato dopo $PONTE_MAX secondi" >> $o
  head -c 61440 $o > $o.cut
  curl -sS -m 30 -H "Authorization: Bearer $T" --data-binary @$o.cut "$(ponte_url)/odin/esito?id=$id&uscita=$e" >/dev/null 2>&1
  log "ponte: comando $id eseguito (uscita $e)"
  rm -f $s $o $o.cut
}

ponte_ciclo() {
  # uno solo: se il processo segnato è ancora vivo esce; se un altro prende il posto, questo si ferma (ciclo sotto)
  p=$(cat $RUN/ponte.pid 2>/dev/null)
  is_num "$p" && [ "$p" != $$ ] && grep -q "ponte.sh" /proc/$p/cmdline 2>/dev/null && return 0
  echo $$ > $RUN/ponte.pid
  # senza chiave o senza indirizzo non riparte fino al riavvio (segno in $RUN): niente registro pieno ogni minuto
  k=$(cat $CFG/remoto.key 2>/dev/null); [ ${#k} = 64 ] || { log "ponte: chiave mancante, fermo"; touch $RUN/ponte_fermo; return 1; }
  T=$(printf 'ponte|%s' "$k" | sha256sum | cut -c1-64)
  case $(ponte_url) in *INDIRIZZO*) log "ponte: indirizzo del worker non ancora impostato"; touch $RUN/ponte_fermo; return 1;; esac
  errori=0
  while [ ! -f $MODDIR/disable ] && [ ! -f $MODDIR/remove ] && [ ! -f $CFG/ponte_no ] && [ "$(cat $RUN/ponte.pid 2>/dev/null)" = $$ ]; do
    r=$RUN/ponte_lavoro
    c=$(curl -sS -m 65 -o $r -w '%{http_code}' -H "Authorization: Bearer $T" "$(ponte_url)/odin/prossimo" 2>/dev/null)
    case $c in
      200) errori=0; ponte_esegui $r;;
      204) errori=0;;
      403) log "ponte: gettone rifiutato dal worker, riprovo fra 10 minuti"; sleep 600;;
      *) errori=$((errori + 1)); [ $errori = 3 ] && log "ponte: worker non raggiungibile (codice ${c:-nessuno})"
         if [ $errori -lt 10 ]; then sleep 10; else sleep 60; fi;;
    esac
    rm -f $r
    echo "$(date +%s) $c" > $RUN/ponte_ultimo
  done
  [ "$(cat $RUN/ponte.pid 2>/dev/null)" = $$ ] && rm -f $RUN/ponte.pid
  return 0
}

[ "$1" = ciclo ] && ponte_ciclo
