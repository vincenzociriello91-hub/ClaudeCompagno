#!/system/bin/sh
# Su LineageOS la ventola (pwm-fan) è guidata dal kernel termico e la velocità
# non si imposta a mano. Si possono però spostare le soglie di temperatura
# collegate SOLO alla ventola, se il kernel lo consente.
fan_cdev() {
  for c in /sys/class/thermal/cooling_device*; do
    [ "$(cat $c/type 2>/dev/null)" = pwm-fan ] && { basename $c; return; }
  done
}
fan_offset() {
  case $FAN in quiet) echo 4000;; sport) echo -5000;; max) echo -10000;; *) echo 0;; esac
}
apply_fan() {
  log "== Ventola: $FAN =="
  CD=$(fan_cdev)
  [ -z "$CD" ] && { log "ventola pwm-fan non trovata"; echo missing > $RUN/fan_state; return; }
  OFF=$(fan_offset); ok=0; ko=0
  for z in /sys/class/thermal/thermal_zone*; do
    for l in $z/cdev[0-9]*; do
      [ -L "$l" ] || continue
      [ "$(basename "$(readlink $l)")" = "$CD" ] || continue
      t=$(cat ${l}_trip_point 2>/dev/null); is_num "$t" || continue
      f=$z/trip_point_${t}_temp
      [ -f "$f" ] || continue
      # mai toccare soglie di emergenza
      case $(cat $z/trip_point_${t}_type 2>/dev/null) in hot|critical) continue;; esac
      # salta soglie condivise con altri dispositivi (limiti CPU/GPU)
      shared=0
      for o in $z/cdev[0-9]*; do
        [ -L "$o" ] && [ "$o" != "$l" ] && [ "$(cat ${o}_trip_point 2>/dev/null)" = "$t" ] && shared=1
      done
      [ $shared = 1 ] && continue
      key=$(basename $z)_$t
      [ -f $RUN/trip_$key ] || cat $f > $RUN/trip_$key      # originale, una volta per avvio
      orig=$(cat $RUN/trip_$key); is_num "$orig" || continue
      new=$((orig + OFF))
      [ $new -lt 40000 ] && new=40000   # mai sotto i 40°C: la ventola non girerebbe sempre
      # resta sempre almeno 5°C sotto le soglie hot/critical della zona
      for tt in $z/trip_point_*_type; do
        case $(cat $tt 2>/dev/null) in hot|critical)
          lim=$(cat ${tt%_type}_temp 2>/dev/null)
          is_num "$lim" && [ $new -gt $((lim - 5000)) ] && new=$orig ;;
        esac
      done
      if echo $new > $f 2>/dev/null && [ "$(cat $f)" = "$new" ]; then ok=$((ok+1)); else ko=$((ko+1)); fi
    done
  done
  if [ $ok -eq 0 ] && [ $ko -gt 0 ]; then
    log "il kernel non permette di cambiare le soglie: ventola in automatico"
    echo unsupported > $RUN/fan_state
  else
    log "soglie ventola modificabili: $ok, bloccate dal kernel: $ko"
    echo ok > $RUN/fan_state
  fi
}
zone_max() {  # zone_max prefisso -> °C massimi tra le zone con quel nome
  m=0
  for z in /sys/class/thermal/thermal_zone*; do
    case $(cat $z/type 2>/dev/null) in $1*)
      t=$(cat $z/temp 2>/dev/null); is_num "$t" && [ $t -gt $m ] && [ $t -lt 150000 ] && m=$t ;;
    esac
  done
  if [ $m -gt 0 ]; then echo $((m / 1000)); else echo "n/d"; fi
}
fan_status() {
  CD=$(fan_cdev)
  if [ -n "$CD" ]; then echo "Ventola: livello $(cat /sys/class/thermal/$CD/cur_state)/$(cat /sys/class/thermal/$CD/max_state)"
  else echo "Ventola: non trovata"; fi
  [ "$(cat $RUN/fan_state 2>/dev/null)" = unsupported ] && echo "  (curva non modificabile su questo kernel: automatica)"
  bt=$(cat /sys/class/power_supply/battery/temp 2>/dev/null); is_num "$bt" || bt=0
  bt=$((bt / 10)); [ $bt -gt 0 ] || bt="n/d"
  echo "Temperature: CPU $(zone_max cpu-)°C  GPU $(zone_max gpuss-)°C  batteria ${bt}°C"
}
