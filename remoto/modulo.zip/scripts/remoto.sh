#!/system/bin/sh
# Assistente remoto (v4.13, comandi firmati di Claude dalla v4.14): Vincenzo comanda la Odin dal pannello del server (anche da fuori casa con Tailscale).
# Il pannello scrive UNA parola in /sdcard/Download/.odin_comando; qui si esegue solo se è nella lista qui sotto.
# Sicurezza: /sdcard è scrivibile da tutte le app, quindi MAI eseguire il contenuto del file: solo azioni fisse.
REM_CMD=/sdcard/Download/.odin_comando
REM_ESITO=/sdcard/Download/.odin_esito
TERMUX_DIR=/data/data/com.termux
MC_BASE=$TERMUX_DIR/files/usr/var/lib/proot-distro/installed-rootfs/debian/root/claudemc
# Canale di Claude: comandi firmati in un file del repository pubblico ClaudeCompagno (ci scrive solo il proprietario).
# Riga: "<numero> <azione> <firma>", firma = sha256("<numero> <azione> <chiave>"); chiave solo sulla Odin e su Drive (privato).
REM_URL=https://raw.githubusercontent.com/vincenzociriello91-hub/ClaudeCompagno/main/remoto/comandi.txt
REM_KEY=$CFG/remoto.key
# Moduli da installare a distanza: lo zip sta qui, ma si installa solo se il comando firmato ne contiene l'impronta sha256
REM_ZIP_URL=https://raw.githubusercontent.com/vincenzociriello91-hub/ClaudeCompagno/main/remoto/modulo.zip

rem_esito() { echo "$(date '+%d/%m %H:%M:%S') $1" > $REM_ESITO.tmp 2>/dev/null && mv -f $REM_ESITO.tmp $REM_ESITO; log "remoto: $1"; }

rem_autosync_pkg() {  # quale Autosync è installato (le versioni nuove e quella vecchia solo-Drive)
  for p in com.ttxapps.autosync com.ttxapps.drivesync; do
    pm path $p >/dev/null 2>&1 && { echo $p; return; }
  done
}

rem_sync_drive() {  # riavvia l'app che sincronizza Odin2_report su Google Drive
  p=$(rem_autosync_pkg)
  [ -n "$p" ] || { rem_esito "Autosync non trovato"; return 1; }
  am force-stop $p >/dev/null 2>&1
  monkey -p $p -c android.intent.category.LAUNCHER 1 >/dev/null 2>&1
  rem_esito "Autosync riavviato ($p)"
}

rem_server() {  # avvia il server Minecraft con lo script di avvio automatico di Termux (come all'accensione)
  if pgrep -f bedrock_server >/dev/null 2>&1; then rem_esito "server già acceso: niente da fare"; return 0; fi
  u=$(stat -c %u $TERMUX_DIR 2>/dev/null)
  b=$(ls $TERMUX_DIR/files/home/.termux/boot/* 2>/dev/null | head -n 1)
  is_num "$u" && [ -n "$b" ] || { rem_esito "avvio del server non trovato (Termux:Boot)"; return 1; }
  P=$TERMUX_DIR/files/usr
  su $u -c "export HOME=$TERMUX_DIR/files/home PREFIX=$P PATH=$P/bin TMPDIR=$P/tmp LD_PRELOAD=$P/lib/libtermux-exec.so; nohup sh '$b' >/dev/null 2>&1 &"
  rem_esito "server avviato"
}

rem_stop() {  # "stop" nella console del server, come mc-ferma (09/11: il TERM a avvia.sh uccideva solo i processi dei rapporti e del pannello, il server restava acceso)
  REM_ERR="console non trovata ($MC_BASE/console)"
  [ -p $MC_BASE/console ] || return 1
  # senza lettore la scrittura resterebbe bloccata: 5 secondi al massimo
  REM_ERR=$(timeout 5 sh -c "echo stop > $MC_BASE/console" 2>&1) || { REM_ERR="scrittura nella console non riuscita: ${REM_ERR:-tempo scaduto}"; return 1; }
  touch $MC_BASE/.stop_richiesto
}

# 10/11/2026: ferma_server ha risposto "server già spento" con il server acceso. Questo controllo non manda nulla
# al server (apre la console in scrittura e la richiude): serve a capire perché lo stop non arriva.
rem_console_diag() {
  echo "utente e contesto: $(id 2>&1)"
  ls -la $MC_BASE/console 2>&1
  if [ -p $MC_BASE/console ]; then echo "fifo: sì"; else echo "fifo: no"; fi
  e=$(timeout 5 sh -c ": > $MC_BASE/console" 2>&1); echo "apertura in scrittura: esito $? ${e:+($e)}"
  echo "timeout usato: $(command -v timeout 2>&1)"
  echo "server: $(pgrep -f bedrock_server 2>/dev/null | tr '\n' ' ')"
}

rem_ferma() {  # chiusura pulita (mondo salvato)
  if rem_stop; then rem_esito "server in chiusura (mondo salvato)"
  elif pgrep -f bedrock_server >/dev/null 2>&1; then rem_esito "server acceso ma lo stop non è arrivato: $REM_ERR"
  else rem_esito "server già spento"; fi
}

rem_riavvia_server() {  # avvia.sh chiude il server e riparte da solo (stesso meccanismo degli aggiornamenti)
  touch $MC_BASE/.riavvia
  if rem_stop; then rem_esito "server in riavvio (circa 1 minuto)"; else rm -f $MC_BASE/.riavvia; rem_server; fi
}

rem_rapporto() {  # tutto lo stato della Odin in un file su Drive
  f=$REPD/odin_remoto_rapporto.txt
  { echo "=== RAPPORTO REMOTO ODIN $(date '+%d/%m/%Y %H:%M:%S') ==="
    echo "acceso da: $(awk '{printf "%.1f ore", $1/3600}' /proc/uptime)"
    echo "temperature: cpu $(zone_max cpu-) °C, gpu $(zone_max gpuss-) °C, batteria $(cat /sys/class/power_supply/battery/temp 2>/dev/null) decimi"
    echo "batteria: $(cat /sys/class/power_supply/battery/capacity 2>/dev/null)% $(cat /sys/class/power_supply/battery/status 2>/dev/null)"
    grep -E 'MemTotal|MemAvailable|SwapTotal|SwapFree' /proc/meminfo
    echo "--- processi principali"; ps -A -o PID,RSS,NAME 2>/dev/null | sort -k2 -n -r | head -n 12
    echo "--- attivi: server $(pgrep -f bedrock_server | head -n 1) | avvia.sh $(pgrep -f claudemc/avvia.sh | head -n 1) | playit $(pgrep -x playit | head -n 1) | autosync $(pidof $(rem_autosync_pkg) 2>/dev/null)"
    echo "--- console del server"; rem_console_diag
    echo "--- spazio"; df -h /data 2>/dev/null | tail -n 1
    echo "--- rete"; ip -4 addr show wlan0 2>/dev/null | grep inet; ping -c 2 -W 2 8.8.8.8 2>/dev/null | tail -n 2
    echo "--- registro modulo"; tail -n 20 $CFG/log.txt 2>/dev/null
  } > $f 2>&1
  rem_esito "rapporto in Odin2_report/odin_remoto_rapporto.txt"
}

rem_libera_ram() {  # svuota la cache dei file e chiude le app in sottofondo (il server resta: è protetto)
  sync; echo 3 > /proc/sys/vm/drop_caches 2>/dev/null; am kill-all >/dev/null 2>&1
  rem_esito "RAM liberata: $(awk '/MemAvailable/{printf "%d MB", $2/1024}' /proc/meminfo) disponibili"
}

rem_installa() {  # installa lo zip approvato (impronta nel comando firmato) e riavvia per attivarlo
  z=$RUN/remoto_modulo.zip; rm -f $z
  curl -fsSL -m 300 -o $z "$REM_ZIP_URL" 2>/dev/null || wget -q -T 300 -O $z "$REM_ZIP_URL" 2>/dev/null
  [ "$(sha256sum $z 2>/dev/null | cut -c1-64)" = "$1" ] || { rm -f $z; rem_esito "modulo rifiutato: impronta diversa da quella approvata"; return 1; }
  if magisk --install-module $z >/dev/null 2>&1; then
    rm -f $z; rem_esito "modulo installato: riavvio per attivarlo"
    sync; svc power reboot >/dev/null 2>&1 || reboot
  else
    rm -f $z; rem_esito "installazione del modulo non riuscita"; return 1
  fi
}

rem_reboot() {  # riavvio della Odin: mai due volte in 30 minuti (niente cicli di riavvii)
  up=$(cut -d. -f1 /proc/uptime 2>/dev/null); is_num "$up" || up=0
  [ $up -ge 1800 ] || { rem_esito "riavvio rifiutato: la Odin è accesa da meno di 30 minuti"; return 1; }
  rem_esito "riavvio della Odin"
  sync; svc power reboot >/dev/null 2>&1 || reboot
}

rem_esegui() {  # solo le azioni della lista; tutto il resto ignorato
  case $1 in
    sync_drive) rem_sync_drive;;
    avvia_server) rem_server;;
    ferma_server) rem_ferma;;
    riavvia_server) rem_riavvia_server;;
    rapporto) rem_rapporto;;
    libera_ram) rem_libera_ram;;
    riavvia_odin) rem_reboot;;
    backup) rem_esito "$(backup_partizioni | tail -n 1)";;
    *) rem_esito "comando sconosciuto, ignorato";;
  esac
}

rem_chiave() {  # chiave creata una volta sulla Odin; copia su Drive (privato) perché Claude possa firmare i comandi
  [ -s $REM_KEY ] || { head -c 32 /dev/urandom | od -An -tx1 | tr -d ' \n' > $REM_KEY; chmod 600 $REM_KEY; }
  [ -f $REPD/remoto_chiave.txt ] || { mkdir -p $REPD; cp $REM_KEY $REPD/remoto_chiave.txt; }
  cat $REM_KEY
}

rem_github() {  # legge i comandi firmati; esegue solo quelli nuovi (numero più alto dell'ultimo) con firma giusta
  k=$(rem_chiave); [ ${#k} = 64 ] || return 0
  t=$( { curl -fsSL -m 20 "$REM_URL" 2>/dev/null || wget -q -T 20 -O - "$REM_URL" 2>/dev/null; } | head -n 50)
  [ -n "$t" ] || return 0
  ult=$(cat $CFG/remoto_ultimo 2>/dev/null); is_num "$ult" || ult=0
  echo "$t" | while read -r num az firma; do
    is_num "$num" || continue
    [ ${#num} -le 10 ] && [ $num -gt $ult ] || continue   # numero = data in secondi (mksh calcola a 32 bit)
    [ "$(printf '%s %s %s' "$num" "$az" "$k" | sha256sum | cut -c1-64)" = "$firma" ] || { grep -qx "$num" $RUN/rem_bad 2>/dev/null || { echo $num >> $RUN/rem_bad; log "remoto: comando $num con firma sbagliata, ignorato"; }; continue; }
    echo $num > $CFG/remoto_ultimo; ult=$num
    case $az in
      aggiorna_modulo:*) h=${az#aggiorna_modulo:}; if [ ${#h} = 64 ]; then rem_installa "$h"; else rem_esito "impronta del modulo non valida"; fi;;
      *) rem_esegui "$az";;
    esac
    cp $REM_ESITO $REPD/remoto_esito.txt 2>/dev/null
  done
}

remoto_tick() {  # dal watcher ogni 5 s
  if [ -f $REM_CMD ]; then
    c=$(head -c 32 $REM_CMD 2>/dev/null | tr -cd 'a-z_'); rm -f $REM_CMD
    rem_esegui "$c"
  fi
  # comandi firmati di Claude da GitHub: un controllo al minuto
  [ $(( $(cat $RUN/rem_n 2>/dev/null || echo 0) % 12 )) = 0 ] && rem_github &   # in sottofondo: la rete non blocca il watcher
  # Autosync fermo (09/11: dopo un riavvio non era ripartito e Drive si è bloccato): lo riapre da solo, controllo ogni 10 minuti
  n=$(cat $RUN/rem_n 2>/dev/null); is_num "$n" || n=0; n=$((n + 1)); echo $n > $RUN/rem_n
  if [ $((n % 120)) = 0 ]; then
    p=$(rem_autosync_pkg)
    [ -n "$p" ] && ! pidof $p >/dev/null 2>&1 && { monkey -p $p -c android.intent.category.LAUNCHER 1 >/dev/null 2>&1; log "Autosync non era attivo: riaperto"; }
  fi
  return 0
}
