#!/system/bin/sh
# Profili CPU/GPU + parametri memoria e I/O (versione Base 8 GB)

# Mantiene il profilo se un altro servizio di Android lo altera, senza mai
# contrastare il sistema:
#  - il massimo viene solo ABBASSATO fino al limite del profilo battery
#    (mai alzato: un massimo più basso può essere un limite termico)
#  - il minimo viene solo RIALZATO fino alla soglia del profilo performance
#    (mai abbassato: un minimo più alto è una "spinta" temporanea del sistema,
#    per esempio all'apertura di un'app, che si esaurisce da sola)
# I valori di riferimento sono quelli VOLUTI dal profilo, non quelli letti.
cpu_reassert() {  # ritorna 0 se ha corretto qualcosa
  [ -f $RUN/cpu_expected ] || return 1
  fixed=1
  while read -r pol mn mx; do
    cmx=$(cat $pol/scaling_max_freq 2>/dev/null); cmn=$(cat $pol/scaling_min_freq 2>/dev/null)
    is_num "$cmx" && is_num "$cmn" && is_num "$mn" && is_num "$mx" || continue
    if [ $cmx -gt $mx ]; then w $mx $pol/scaling_max_freq; fixed=0; cmx=$mx; fi
    if [ $cmn -lt $mn ] && [ $mn -le $cmx ]; then w $mn $pol/scaling_min_freq; fixed=0; fi
  done < $RUN/cpu_expected
  if [ -s $RUN/bus_expected ]; then
    while read -r f v; do
      [ "$(cat $f 2>/dev/null)" = "$v" ] || { w $v $f; fixed=0; }
    done < $RUN/bus_expected
  fi
  return $fixed
}

# --- Bus di memoria (bus_dcvs Qualcomm): RAM DDR, cache LLCC e L3 -------------
# Profilo turbo: richiesta di frequenza minima = massimo di fabbrica (hw_max_freq),
# più priorità alla memoria (DDRQOS). Gli altri profili rimettono il valore
# originale, letto una volta per avvio. Non si supera mai hw_max_freq.
BUSD=/sys/devices/system/cpu/bus_dcvs
apply_bus() {
  : > $RUN/bus_expected
  for n in DDR LLCC L3 DDRQOS; do
    d=$BUSD/$n; [ -w $d/boost_freq ] || continue
    [ -f $RUN/bus_orig_$n ] || cat $d/boost_freq > $RUN/bus_orig_$n 2>/dev/null
    if [ "$PROFILE" = turbo ]; then v=$(cat $d/hw_max_freq 2>/dev/null)
    else v=$(cat $RUN/bus_orig_$n 2>/dev/null); is_num "$v" || v=$(cat $d/hw_min_freq 2>/dev/null); fi
    is_num "$v" || continue
    w $v $d/boost_freq
    echo "$d/boost_freq $v" >> $RUN/bus_expected
  done
  [ -s $RUN/bus_expected ] && [ "$PROFILE" = turbo ] && log "memoria: RAM $(cat $BUSD/DDR/cur_freq 2>/dev/null) kHz, LLCC $(cat $BUSD/LLCC/cur_freq 2>/dev/null), L3 $(cat $BUSD/L3/cur_freq 2>/dev/null) (massimo)"
}

pick_pct() {  # pick_pct "lista frequenze" percentuale -> frequenza
  set -- $(echo $1 | tr ' ' '\n' | grep . | sort -n) "$2"
  eval pct=\${$#}; n=$(($# - 1))
  [ $n -lt 1 ] && return
  i=$(( (n - 1) * pct / 100 + 1 )); eval echo \${$i}
}

apply_cpu() {
  log "== CPU/GPU: $PROFILE =="
  for pol in /sys/devices/system/cpu/cpufreq/policy*; do
    [ -f "$pol/cpuinfo_max_freq" ] || continue
    MAX=$(cat $pol/cpuinfo_max_freq); MIN=$(cat $pol/cpuinfo_min_freq)
    LIST=$(cat $pol/scaling_available_frequencies 2>/dev/null)
    # valori VOLUTI dal profilo
    vmin=$MIN; vmax=$MAX
    if [ -n "$LIST" ]; then
      case $PROFILE in
        performance) vmin=$(pick_pct "$LIST" 40) ;;
        turbo)       vmin=$(pick_pct "$LIST" 80) ;;
        battery)     vmax=$(pick_pct "$LIST" 70) ;;
        server)      vmax=$(pick_pct "$LIST" 85) ;;   # server: niente picchi inutili (consumano), minimo di fabbrica
      esac
    fi
    is_num "$vmin" || vmin=$MIN; is_num "$vmax" || vmax=$MAX
    # prima la finestra completa, poi il profilo (evita minimo > massimo)
    w "$MIN" $pol/scaling_min_freq; w "$MAX" $pol/scaling_max_freq
    w "$vmax" $pol/scaling_max_freq; w "$vmin" $pol/scaling_min_freq
    log "$(basename $pol): profilo $vmin-$vmax kHz (ora $(cat $pol/scaling_min_freq)-$(cat $pol/scaling_max_freq))"
    echo "$pol $vmin $vmax"
  done > $RUN/cpu_expected

  # GPU Adreno 740: solo la frequenza minima, le protezioni termiche restano attive
  K=/sys/class/kgsl/kgsl-3d0
  w 0 $K/force_clk_on      # annulla eventuali modifiche delle versioni precedenti
  w 1 $K/throttling
  G=$K/devfreq
  if [ -f $G/min_freq ] && [ -f $G/available_frequencies ]; then
    GL=$(cat $G/available_frequencies)
    # minimo di fabbrica = frequenza più bassa (non quella letta: potrebbe essere una spinta)
    case $PROFILE in
      performance) w "$(pick_pct "$GL" 40)" $G/min_freq ;;
      turbo)       w "$(pick_pct "$GL" 90)" $G/min_freq ;;     # Adreno 740: 615 MHz
      *)           w "$(pick_pct "$GL" 0)" $G/min_freq ;;
    esac
    log "GPU min: $(cat $G/min_freq)"
  fi

  apply_bus

  # Memoria: con 8 GB conviene usare molto la zram
  w 100 /proc/sys/vm/swappiness
  w 200 /proc/sys/vm/watermark_scale_factor
  w 0   /proc/sys/vm/page-cluster          # consigliato per zram
  w 15  /proc/sys/vm/dirty_ratio
  w 5   /proc/sys/vm/dirty_background_ratio
  if [ "$PROFILE" = performance ]; then w 50 /proc/sys/vm/vfs_cache_pressure
  else w 100 /proc/sys/vm/vfs_cache_pressure; fi

  # I/O: read-ahead più ampio per caricare ROM e giochi
  for q in /sys/block/sd*/queue /sys/block/mmcblk*/queue /sys/block/dm-*/queue; do
    [ -d "$q" ] || continue
    w 512 $q/read_ahead_kb
    w 1   $q/iostats          # annulla la modifica delle versioni precedenti
  done
}
