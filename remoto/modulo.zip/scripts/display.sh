#!/system/bin/sh
# Frequenza dello schermo per app (Odin 2 Portal: 60/90/120/144/165 Hz).
# Si usano le impostazioni di sistema peak/min_refresh_rate; i valori originali
# vengono salvati in modo permanente e ripristinati all'uscita dall'app, dopo
# un riavvio, alla disattivazione e alla disinstallazione del modulo.
HZF=$CFG/hz_orig
hz_validi() { dumpsys display 2>/dev/null | grep -oE 'fps=[0-9]+' | cut -d= -f2 | sort -un; }
hz_set() {  # hz_set N   (auto = non toccare)
  [ "$AUTO_HZ" = on ] || return 0
  is_num "$1" || return 0
  hz_validi | grep -qx "$1" || { log "schermo: $1 Hz non supportati, salto"; return 0; }
  if [ ! -f $HZF ]; then
    o1=$(sget system peak_refresh_rate); o2=$(sget system min_refresh_rate)
    if [ "$o1" = ERR ] || [ "$o2" = ERR ]; then
      log "schermo: impostazioni non leggibili, frequenza non cambiata (per sicurezza)"; return 0
    fi
    echo "$o1 $o2" > $HZF
  fi
  sput system peak_refresh_rate $1.0
  sput system min_refresh_rate $1.0
  log "schermo: $1 Hz"
}
hz_valore() { case $1 in null|"") echo null;; *[!0-9.]*) echo null;; *) echo $1;; esac; }
hz_restore() {
  [ -f $HZF ] || return 0
  read -r pk mn < $HZF
  pk=$(hz_valore "$pk"); mn=$(hz_valore "$mn")
  if [ "$pk" = null ]; then sdel system peak_refresh_rate; else sput system peak_refresh_rate "$pk"; fi
  if [ "$mn" = null ]; then sdel system min_refresh_rate; else sput system min_refresh_rate "$mn"; fi
  rm -f $HZF
  log "schermo: frequenza originale ripristinata"
}
