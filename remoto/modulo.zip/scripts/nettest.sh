#!/system/bin/sh
# Test connessione per cloud gaming
pingstat() {  # host n -> "media jitter perdita% picco"
  ping -c $2 -i 0.2 -W 1 $1 2>/dev/null | awk -v n=$2 '
    /time[=<]/{ s0=$0; sub(/.*time[=<]/,"",s0); t=s0+0; c++; s+=t
               if(c>1){d=t-p; if(d<0)d=-d; j+=d}; p=t; if(t>m)m=t }
    END{ if(c==0){print "- - 100 -"; exit}
         printf "%.1f %.1f %d %.0f\n", s/c, (c>1?j/(c-1):0), (n-c)*100/n, m }'
}
nettest_cleanup() {
  [ "$lowset" = 1 ] && cmd wifi force-low-latency-mode disabled >/dev/null 2>&1
  lowset=0
}
nettest() {
  echo "Test connessione (circa 30 secondi)..."
  lowset=0
  trap 'nettest_cleanup; exit 1' INT TERM HUP
  if [ ! -f $RUN/cloud_active ]; then
    cmd wifi force-low-latency-mode enabled >/dev/null 2>&1 && lowset=1
  fi
  wi=$(dumpsys wifi 2>/dev/null | grep -m1 'mWifiInfo')
  freq=$(echo "$wi" | grep -oE 'Frequency: [0-9]+' | head -n1 | grep -oE '[0-9]+')
  rssi=$(echo "$wi" | grep -oE 'RSSI: -?[0-9]+' | head -n1 | grep -oE '[-]?[0-9]+')
  speed=$(echo "$wi" | grep -oE 'Link speed: [0-9]+' | head -n1 | grep -oE '[0-9]+')
  rxs=$(echo "$wi" | grep -oE 'Rx Link speed: [0-9]+' | head -n1 | grep -oE '[0-9]+')
  std=$(echo "$wi" | grep -oE 'Wi-Fi standard: [0-9a-z]+' | head -n1 | cut -d' ' -f3)
  route=$(ip route get 1.1.1.1 2>/dev/null)
  dev=$(echo "$route" | grep -oE 'dev [a-z0-9_]+' | cut -d' ' -f2)
  gw=$(echo "$route" | grep -oE 'via [0-9.]+' | cut -d' ' -f2)
  tips=""; band=""
  tip() { tips="$tips
 - $1"; }

  echo
  case $dev in
    wlan*)
      if is_num "$freq"; then
        if [ $freq -lt 3000 ]; then band="2,4 GHz"; tip "Sei sui 2,4 GHz: collegati alla rete 5 GHz o 6 GHz del router"
        elif [ $freq -lt 5925 ]; then band="5 GHz"; else band="6 GHz"; fi
      fi
      echo "Wi-Fi: ${band:-?}  segnale ${rssi:-?} dBm  velocità ${speed:-?} Mbps (ricezione ${rxs:-?})  standard ${std:-?}"
      if is_num "$freq" && [ $freq -ge 5250 ] && [ $freq -le 5730 ]; then
        echo "  canale DFS ($((freq / 5 - 1000)))"
        tip "Il router usa un canale DFS (52-144): se rileva un radar cambia canale e la connessione cade per qualche secondo. Imposta un canale fisso tra 36 e 48"
      fi
      case $rssi in -[0-9]*)
        if [ $rssi -lt -70 ]; then echo "  segnale: DEBOLE"; tip "Segnale debole: avvicinati al router o usa un sistema mesh"
        elif [ $rssi -lt -60 ]; then echo "  segnale: discreto"; [ $rssi -lt -65 ] && tip "Segnale sotto -65 dBm: per il cloud gaming meglio avvicinarsi al router"
        else echo "  segnale: buono"; fi ;;
      esac ;;
    "") echo "Connessione: nessuna rete"; nettest_cleanup; trap - INT TERM HUP; return ;;
    *) echo "Connessione: cavo/adattatore ($dev)" ;;
  esac

  # prima internet, poi il router: serve il confronto tra i due
  host=1.1.1.1; inet=$(pingstat $host 60)
  set -- $inet; [ "$1" = - ] && { host=8.8.8.8; inet=$(pingstat $host 60); }

  if [ -n "$gw" ]; then
    set -- $(pingstat $gw 50)
    echo; echo "Console -> router (qualità della rete di casa)"
    echo "  ping $1 ms  jitter $2 ms  persi $3%  picco $4 ms"
    ia=$(echo $inet | cut -d' ' -f1)
    if [ "$1" = - ]; then echo "  (il router non risponde al ping: normale per alcuni modelli)"
    elif [ "$ia" != - ] && [ ${1%.*} -gt ${ia%.*} ]; then
      # il router risponde più lento di un server su internet che passa da lui:
      # risponde ai ping con bassa priorità, il dato non descrive il Wi-Fi
      echo "  (il router risponde lentamente ai test: normale per molti modelli, valore non indicativo)"
    else
      [ "$3" != 0 ] && tip "Pacchetti persi già verso il router: Wi-Fi disturbato o troppo lontano"
      [ ${2%.*} -ge 5 ] && tip "Jitter alto verso il router: Wi-Fi instabile (canale affollato o distanza)"
      [ ${4%.*} -ge 50 ] && tip "Picchi di ping in casa: controlla che nessuno stia scaricando o guardando video in 4K"
    fi
  fi

  set -- $inet
  echo; echo "Console -> internet ($host)"
  echo "  ping $1 ms  jitter $2 ms  persi $3%  picco $4 ms"
  if [ "$1" = - ]; then v="nessuna risposta (internet assente o ping bloccato)"
  else
    a=${1%.*}
    if [ $a -lt 25 ]; then v="OTTIMO per il cloud gaming"
    elif [ $a -lt 40 ]; then v="BUONO"
    elif [ $a -lt 60 ]; then v="GIOCABILE, ma si sente nei giochi veloci"
    else v="ALTO"; tip "Ping alto: controlla nell'app di cloud gaming quale server/area stai usando"; fi
    [ ${2%.*} -ge 8 ] && tip "Jitter alto su internet: ripeti il test quando in casa nessuno usa la rete; se resta alto attiva SQM/QoS sul router o abbassa la qualità dello streaming"
    [ ${4%.*} -ge 100 ] && tip "Picchi oltre 100 ms: nel cloud gaming si sentono come scatti improvvisi"
    [ "$3" != 0 ] && tip "Pacchetti persi su internet: possibile problema della linea o del provider"
  fi
  echo "  giudizio: $v"

  nettest_cleanup; trap - INT TERM HUP
  echo
  if [ -n "$tips" ]; then echo "Consigli:$tips"; else echo "Nessun problema trovato."; fi
  echo "$(date '+%d/%m %H:%M') ${band:-$dev} rssi=${rssi:-?} internet=${1}ms jitter=${2}ms persi=${3}%" >> $CFG/nettest.log
  tail -n 50 $CFG/nettest.log > $CFG/nettest.tmp && mv $CFG/nettest.tmp $CFG/nettest.log
}
