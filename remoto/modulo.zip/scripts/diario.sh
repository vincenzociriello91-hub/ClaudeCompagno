#!/system/bin/sh
# App Diario Odin: la installa (o aggiorna) e le dà i permessi, così parte da sola.
DPKG=com.vincenzo.diarioodin

diario_setup() {
  a=$MODDIR/app/DiarioOdin.apk
  [ -f "$a" ] || return 0
  want=$(cat $MODDIR/app/versione 2>/dev/null)
  have=$(dumpsys package $DPKG 2>/dev/null | awk '/versionCode=/{sub(/.*versionCode=/,""); sub(/ .*/,""); print; exit}')
  if [ "$have" != "$want" ]; then
    # pm non legge dentro /data/adb: copia temporanea
    cp "$a" /data/local/tmp/diario.apk 2>/dev/null
    if pm install -r /data/local/tmp/diario.apk </dev/null >/dev/null 2>&1; then log "diario: app installata (versione $want)"
    # ogni versione è firmata con una chiave nuova: Android rifiuta l'aggiornamento sopra, quindi via e di nuovo
    elif pm uninstall $DPKG </dev/null >/dev/null 2>&1 && pm install /data/local/tmp/diario.apk </dev/null >/dev/null 2>&1; then
      log "diario: app reinstallata (versione $want, i report già scritti restano)"
    else log "diario: installazione dell'app non riuscita"; fi
    rm -f /data/local/tmp/diario.apk
  fi
  pm path $DPKG </dev/null >/dev/null 2>&1 || return 0
  appops set $DPKG MANAGE_EXTERNAL_STORAGE allow </dev/null >/dev/null 2>&1
  appops set $DPKG ACCESS_RESTRICTED_SETTINGS allow </dev/null >/dev/null 2>&1
  cmd notification allow_listener $DPKG/$DPKG.NotificheService </dev/null >/dev/null 2>&1
  cmd deviceidle whitelist +$DPKG </dev/null >/dev/null 2>&1
  # lettura dello schermo: aggiunge il servizio a quelli già attivi senza toglierne nessuno
  svc=$DPKG/$DPKG.SchermoService
  cur=$(settings get secure enabled_accessibility_services </dev/null 2>/dev/null)
  case $cur in
    *"$svc"*) ;;
    ""|null) sput secure enabled_accessibility_services "$svc" ;;
    *[!a-zA-Z0-9_.:/\$]*) log "diario: elenco Accessibilità illeggibile, servizio non attivato" ;;  # errore di settings: non sovrascrivere
    *) sput secure enabled_accessibility_services "$cur:$svc" ;;
  esac
  sput secure accessibility_enabled 1
  # root senza domanda di Magisk (lettura di tocchi/tasti e del registro crash)
  uid=$(stat -c %u /data/data/$DPKG 2>/dev/null)
  is_num "$uid" && magisk --sqlite "REPLACE INTO policies (uid,policy,until,logging,notification) VALUES($uid,2,0,0,0)" </dev/null >/dev/null 2>&1
  return 0
}
