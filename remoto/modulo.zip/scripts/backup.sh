#!/system/bin/sh
# Copia di sicurezza delle partizioni di avvio (v4.17), da fare prima di cambiare kernel. Solo lettura.
# Va in Odin2_report/backup_kernel, che Autosync porta su Google Drive: una Odin che non si avvia si ripristina
# dal PC, quindi la copia deve stare anche fuori dalla console. Ogni copia viene riletta e confrontata con l'originale.
BKD=$REPD/backup_kernel
backup_partizioni() {  # ritorna 0 solo se tutte le copie sono verificate
  f=$REPD/backup_partizioni.txt
  mkdir -p $BKD 2>/dev/null || { echo "ESITO: cartella non creabile ($BKD)"; return 1; }
  sl=$(getprop ro.boot.slot_suffix 2>/dev/null); bad=0; n_ok=0
  {
    echo "=== BACKUP PARTIZIONI DI AVVIO $(date '+%d/%m/%Y %H:%M:%S') ==="
    echo "kernel: $(uname -r) | slot attivo: ${sl:-unico}"
    free=$(df -Pk /data 2>/dev/null | awk 'NR==2{print int($4/1024)}')
    if ! is_num "$free" || [ $free -lt 2048 ]; then echo "ERRORE: servono 2 GB liberi (ora: ${free:-?} MB)"; bad=1
    else
      for n in boot init_boot vendor_boot vendor_kernel_boot dtbo vbmeta vbmeta_system recovery vendor_dlkm system_dlkm; do
        p=""; for c in /dev/block/by-name/$n$sl /dev/block/mapper/$n$sl; do [ -e $c ] && { p=$c; break; }; done
        [ -n "$p" ] || { echo "$n$sl: non presente su questa console"; continue; }
        o=$BKD/$n$sl.img.gz
        h=$(sha256sum < $p 2>/dev/null | cut -c1-64)
        if [ ${#h} = 64 ] && gzip -c < $p > $o.tmp 2>/dev/null && [ "$(gzip -dc < $o.tmp 2>/dev/null | sha256sum | cut -c1-64)" = "$h" ]; then
          mv -f $o.tmp $o; n_ok=$((n_ok + 1)); echo "$n$sl: OK verificata | $(stat -c %s $o) byte compressi | sha256 $h"
        else rm -f $o.tmp; bad=1; echo "$n$sl: ERRORE (copia non riuscita o diversa dall'originale)"; fi
      done
    fi
    [ -f $BKD/boot$sl.img.gz ] || bad=1
    echo
    echo "=== DATI PER I PROSSIMI PASSI ==="
    echo "--- app installate"; pm list packages -3 2>/dev/null | sed 's/^package://' | sort
    echo "--- carica"
    for x in battery/charge_control_limit battery/charge_control_limit_max battery/charge_type usb/input_current_limit; do
      echo "$x = $(cat /sys/class/power_supply/$x 2>&1)"; done
  } > $f 2>&1
  if [ $bad = 0 ] && [ $n_ok -gt 0 ]; then e="ESITO: BACKUP COMPLETO E VERIFICATO ($n_ok partizioni) in Download/Odin2_report/backup_kernel"
  else e="ESITO: BACKUP NON VALIDO: non cambiare kernel. Dettagli in Download/Odin2_report/backup_partizioni.txt"; fi
  echo "$e" >> $f; echo "$e"
  [ $bad = 0 ] && [ $n_ok -gt 0 ]
}

# Dati per ricompilare un kernel identico a quello installato (v4.21, passo kernel del "sistema perfetto").
# Scritti all'avvio, una volta per kernel (versione e data di compilazione: il kernel su misura ha la stessa versione
# dell'originale): kernel_info.txt (riassunto) e kernel_config.txt (tutto).
# Solo lettura. Servono a sapere se i moduli della ROM restano validi con un kernel ricompilato.
kernel_info() {
  f=$REPD/kernel_info.txt; v="$(uname -r) | $(uname -v)"
  [ "$(head -n 1 $f 2>/dev/null)" = "kernel: $v" ] && [ -s $REPD/kernel_config.txt ] && return 0
  mkdir -p $REPD 2>/dev/null || return 0
  zcat /proc/config.gz > $REPD/kernel_config.txt 2>/dev/null
  {
    echo "kernel: $v"
    cat /proc/version
    echo "cmdline: $(cat /proc/cmdline 2>&1)"
    echo "impronta della configurazione (righe CONFIG_ ordinate): $(grep '^CONFIG_' $REPD/kernel_config.txt | sort | sha256sum | cut -c1-64)"
    echo "--- opzioni che decidono se i moduli della ROM restano validi"
    grep -E '^(# )?CONFIG_(MODULE_SIG[A-Z0-9_]*|MODVERSIONS|TRIM_UNUSED_KSYMS|UNUSED_KSYMS_WHITELIST|LTO[A-Z0-9_]*|CFI_[A-Z0-9_]*|LOCALVERSION[A-Z0-9_]*|MODULE_SCMVERSION|TCP_CONG_[A-Z0-9_]*|DEFAULT_TCP_CONG|CC_VERSION_TEXT|CLANG_VERSION|LLD_VERSION|SHADOW_CALL_STACK|DEBUG_INFO_BTF[A-Z0-9_]*|FUTEX[A-Z0-9_]*|KERNEL_[A-Z0-9]*|PGTABLE_LEVELS|ARM64_VA_BITS)[= ]' $REPD/kernel_config.txt
    echo "--- stato dei moduli"
    echo "caricati: $(wc -l < /proc/modules) | kernel segnato (tainted): $(cat /proc/sys/kernel/tainted 2>&1) | firma obbligatoria: $(cat /sys/module/module/parameters/sig_enforce 2>&1)"
    for d in /vendor_dlkm/lib/modules /system_dlkm/lib/modules /vendor/lib/modules /lib/modules; do
      echo "$d: $(find $d -name '*.ko' 2>/dev/null | wc -l) moduli"
    done
    for m in $(find /vendor_dlkm/lib/modules /system_dlkm/lib/modules /vendor/lib/modules -name zram.ko -o -name qti_battery_charger.ko -o -name msm_drm.ko 2>/dev/null | head -n 4); do
      echo "$m: $(modinfo $m 2>/dev/null | grep -m1 vermagic) | firme in coda: $(tail -c 28 $m | grep -c 'signature appended')"
    done
    echo "--- simboli (BBR, futex_waitv)"
    grep -E ' __ksymtab_(tcp_register_congestion_control|tcp_unregister_congestion_control|minmax_running_max|tcp_tso_autosize|prandom_u32)$| (__arm64_)?sys_futex_waitv$' /proc/kallsyms | awk '{print $3}' | tr '\n' ' '; echo
    echo "simboli esportati in tutto: $(grep -c ' __ksymtab_' /proc/kallsyms)"
    echo "congestione TCP: $(cat /proc/sys/net/ipv4/tcp_available_congestion_control 2>&1) | swap: $(awk 'NR>1{printf "%s ", $1}' /proc/swaps 2>&1)"
    echo "--- moduli rifiutati dal kernel (deve restare vuoto)"
    dmesg 2>/dev/null | grep -E 'disagrees about version of symbol|Unknown symbol|Invalid module format|Exec format error' | head -n 15
    echo "--- sistema"
    for p in ro.lineage.version ro.build.fingerprint ro.boot.slot_suffix ro.boot.verifiedbootstate ro.boot.vbmeta.device_state ro.boot.flash.locked; do echo "$p = $(getprop $p)"; done
    echo "partizioni: $(ls /dev/block/by-name 2>/dev/null | tr '\n' ' ')"
    echo "--- carica (driver Qualcomm e controllo della ricarica di LineageOS)"
    for d in /sys/class/qcom-battery /sys/class/power_supply/battery; do
      for n in $d/*; do [ -f $n ] && echo "$n = $(head -c 80 $n 2>&1 | tr '\n' ' ')"; done
    done
    getprop | grep -i -E 'charg|bypass' | head -n 20
  } > $CFG/kernel_info.tmp 2>&1
  mv -f $CFG/kernel_info.tmp $f   # intero o niente: chi lo legge da Drive non lo trova mai a metà
}

# Immagine di prova del kernel su misura (v4.22). Prende il boot di adesso, ci mette il kernel compilato su GitHub (zip con
# l'impronta approvata nel comando firmato; nel nome c'è la versione esatta del kernel acceso) e salva tutto in
# Odin2_report/kernel_prova. NON scrive nessuna partizione: l'immagine si avvia una volta dal PC con "fastboot boot" e,
# se non parte, basta riavviare. Accanto c'è boot_originale.img, già pronta per un ripristino dal PC.
KP_URL=https://github.com/vincenzociriello91-hub/DiarioOdin-build/releases/download
kernel_prova() {  # $1 = numero della compilazione, $2 = impronta approvata dello zip
  f=$REPD/kernel_prova.txt; o=$REPD/kernel_prova; t=$CFG/kp; mb=/data/adb/magisk/magiskboot
  v=$(uname -r); sl=$(getprop ro.boot.slot_suffix 2>/dev/null); z=$t/k.zip; u=$KP_URL/kernel-$v-$1/Odin2Portal-kernel-$v-misura.zip; e=""
  rm -rf $t; mkdir -p $t/v $o 2>/dev/null; rm -f $o/boot_prova.img
  {
    echo "=== IMMAGINE DI PROVA DEL KERNEL $(date '+%d/%m/%Y %H:%M:%S') ==="
    echo "kernel acceso: $v | slot: ${sl:-unico} | compilazione $1"
    echo "sistema: $(getprop ro.lineage.version 2>/dev/null)"   # il programma di installazione rifiuta l'immagine se LineageOS è cambiato
    free=$(df -Pk /data 2>/dev/null | awk 'NR==2{print int($4/1024)}')
    if ! is_num "$free" || [ $free -lt 1024 ]; then e="serve 1 GB libero (ora: ${free:-?} MB)"
    elif { curl -fsSL -m 600 -o $z "$u" 2>/dev/null || wget -q -T 600 -O $z "$u" 2>/dev/null; [ "$(sha256sum $z 2>/dev/null | cut -c1-64)" != "$2" ]; }; then e="zip del kernel non scaricato o diverso da quello approvato"
    elif ! unzip -o -q $z Image -d $t 2>/dev/null || ! grep -q -a "Linux version $v " $t/Image; then e="nello zip non c'è il kernel $v"
    elif [ ! -x $mb ]; then e="magiskboot non trovato"
    elif ! cat /dev/block/by-name/boot$sl > $t/boot.img 2>/dev/null || ! (cd $t && $mb unpack boot.img >/dev/null 2>&1 && [ -s kernel ]); then e="partizione boot non leggibile"
    elif ! grep -q -a "Linux version $v " $t/kernel; then e="il kernel dentro boot non è quello acceso"
    elif ! (cd $t && cp Image kernel && $mb repack boot.img boot_prova.img >/dev/null 2>&1 && cd v && $mb unpack ../boot_prova.img >/dev/null 2>&1) || ! cmp -s $t/v/kernel $t/Image; then e="immagine di prova non riuscita"
    elif [ "$(stat -c %s $t/boot_prova.img)" -gt "$(stat -c %s $t/boot.img)" ]; then e="immagine di prova più grande della partizione boot"
    elif ! cp $t/boot_prova.img $o/boot_prova.img || ! cp $t/boot.img $o/boot_originale.img || ! cmp -s $t/boot_prova.img $o/boot_prova.img || ! cmp -s $t/boot.img $o/boot_originale.img; then e="copia in Odin2_report non riuscita"
    else for i in boot_prova boot_originale; do echo "$i.img: $(stat -c %s $o/$i.img) byte | sha256 $(sha256sum $o/$i.img | cut -c1-64)"; done; fi
  } > $f 2>&1
  rm -rf $t
  if [ -n "$e" ]; then rm -f $o/boot_prova.img; e="ESITO: IMMAGINE DI PROVA NON CREATA: $e"
  else e="ESITO: IMMAGINE DI PROVA PRONTA in Download/Odin2_report/kernel_prova (nessuna partizione modificata)"; fi
  echo "$e" >> $f; echo "$e"
}

# Dopo un aggiornamento di LineageOS torna il kernel originale. Se sulla console c'era quello su misura (segno in $CFG),
# all'avvio lo si dice una volta: nel registro e con una notifica. Rimetterlo richiede Claude e il cavo: qui si avvisa soltanto.
kernel_avviso() {
  if grep -q ' __arm64_sys_futex_waitv$' /proc/kallsyms 2>/dev/null; then touch $CFG/kernel_misura
  elif [ -f $CFG/kernel_misura ]; then
    log "kernel: è tornato quello originale (senza futex_waitv)"
    cmd notification post -t "Odin 2 Portal" odin2_kernel "È tornato il kernel originale: scrivi \"kernel\" a Claude per rimettere quello su misura" >/dev/null 2>&1
  fi
  return 0
}
