#!/system/bin/sh
# Copia di sicurezza delle partizioni di avvio (v4.17), da fare prima di cambiare kernel. Solo lettura.
# Va in Odin2_report/backup_kernel, che Autosync porta su Google Drive: una Odin che non si avvia si ripristina
# dal PC, quindi la copia deve stare anche fuori dalla console. Ogni copia viene riletta e confrontata con l'originale.
BKD=$REPD/backup_kernel
backup_partizioni() {  # ritorna 0 solo se tutte le copie sono verificate
  f=$REPD/backup_partizioni.txt
  mkdir -p $BKD 2>/dev/null || { echo "ESITO: cartella non creabile ($BKD)"; return 1; }
  sl=$(getprop ro.boot.slot_suffix 2>/dev/null); bad=0; n_ok=0
  {
    echo "=== BACKUP PARTIZIONI DI AVVIO $(date '+%d/%m/%Y %H:%M:%S') ==="
    echo "kernel: $(uname -r) | slot attivo: ${sl:-unico}"
    free=$(df -Pk /data 2>/dev/null | awk 'NR==2{print int($4/1024)}')
    if ! is_num "$free" || [ $free -lt 2048 ]; then echo "ERRORE: servono 2 GB liberi (ora: ${free:-?} MB)"; bad=1
    else
      for n in boot init_boot vendor_boot vendor_kernel_boot dtbo vbmeta vbmeta_system recovery vendor_dlkm system_dlkm; do
        p=""; for c in /dev/block/by-name/$n$sl /dev/block/mapper/$n$sl; do [ -e $c ] && { p=$c; break; }; done
        [ -n "$p" ] || { echo "$n$sl: non presente su questa console"; continue; }
        o=$BKD/$n$sl.img.gz
        h=$(sha256sum < $p 2>/dev/null | cut -c1-64)
        if [ ${#h} = 64 ] && gzip -c < $p > $o.tmp 2>/dev/null && [ "$(gzip -dc < $o.tmp 2>/dev/null | sha256sum | cut -c1-64)" = "$h" ]; then
          mv -f $o.tmp $o; n_ok=$((n_ok + 1)); echo "$n$sl: OK verificata | $(stat -c %s $o) byte compressi | sha256 $h"
        else rm -f $o.tmp; bad=1; echo "$n$sl: ERRORE (copia non riuscita o diversa dall'originale)"; fi
      done
    fi
    [ -f $BKD/boot$sl.img.gz ] || bad=1
    echo
    echo "=== DATI PER I PROSSIMI PASSI ==="
    echo "--- app installate"; pm list packages -3 2>/dev/null | sed 's/^package://' | sort
    echo "--- carica"
    for x in battery/charge_control_limit battery/charge_control_limit_max battery/charge_type usb/input_current_limit; do
      echo "$x = $(cat /sys/class/power_supply/$x 2>&1)"; done
  } > $f 2>&1
  if [ $bad = 0 ] && [ $n_ok -gt 0 ]; then e="ESITO: BACKUP COMPLETO E VERIFICATO ($n_ok partizioni) in Download/Odin2_report/backup_kernel"
  else e="ESITO: BACKUP NON VALIDO: non cambiare kernel. Dettagli in Download/Odin2_report/backup_partizioni.txt"; fi
  echo "$e" >> $f; echo "$e"
  [ $bad = 0 ] && [ $n_ok -gt 0 ]
}
