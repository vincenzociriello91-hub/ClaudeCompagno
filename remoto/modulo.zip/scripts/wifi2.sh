#!/system/bin/sh
# Doppio Wi-Fi (v4.28): la Odin resta collegata a due reti insieme, una a 5 GHz e una a 2,4 GHz,
# come faceva il sistema originale AYN. Funzione di Android (STA + STA "multi internet"): il chip lo
# supporta ("STA + STA Concurrency Supported: true"), LineageOS la tiene spenta con un flag.
# Prove dal vivo del 13/11/2026 (Termux, Android 16 / LineageOS 24):
#  - il flag si accende a sistema avviato con force-overlay-config-value (vale fino al riavvio);
#  - la richiesta della seconda rete è "add-request -s -i -d <banda>": -s DEVE essere la prima opzione
#    e dopo non va scritto né SSID né sicurezza (altrimenti la banda non viene letta);
#  - la seconda rete deve stare sulla banda diversa da quella principale (stessa banda non permessa).
# Tutto vive nella memoria del servizio Wi-Fi: sparisce da solo al riavvio. Il modulo lo riaccende
# all'avvio, a meno che Vincenzo non l'abbia spento con doppio_wifi_off (segno $CFG/doppio_wifi_no).
W2_FLAG=config_wifiMultiStaMultiInternetConcurrencyEnabled

w2_cmd() { cmd wifi "$@" </dev/null 2>&1; }

w2_banda_principale() {  # 2 o 5: banda della rete a cui è collegata adesso la Odin (vuoto se non collegata)
  f=$(w2_cmd status | grep -o 'Frequency: [0-9]*' | head -n 1 | tr -cd '0-9')
  is_num "$f" || return 0
  if [ $f -lt 3000 ]; then echo 2; else echo 5; fi
}

w2_on() {  # accende il doppio Wi-Fi; scrive il testo dell'esito
  b=$(w2_banda_principale)
  [ -n "$b" ] || { echo "doppio Wi-Fi: la Odin non è collegata a nessuna rete, riprovo più tardi"; return 1; }
  if [ $b = 5 ]; then a=2; else a=5; fi
  r=$(w2_cmd force-overlay-config-value bool $W2_FLAG enabled true)
  case $r in *true*) ;; *) echo "doppio Wi-Fi: flag non accettato ($(echo "$r" | head -n 1))"; return 1;; esac
  w2_cmd set-multi-internet-mode 2 >/dev/null
  w2_cmd remove-all-requests >/dev/null
  r=$(w2_cmd add-request -s -i -d $a)
  case $r in *"Adding request"*) ;; *) echo "doppio Wi-Fi: richiesta rifiutata ($(echo "$r" | head -n 2 | tr '\n' ' '))"; return 1;; esac
  echo $b > $RUN/wifi2
  w2_cmd start-scan >/dev/null
  echo "doppio Wi-Fi acceso: principale a $b GHz, seconda rete cercata a $a GHz"
}

w2_off() {
  w2_cmd remove-all-requests >/dev/null
  w2_cmd set-multi-internet-mode 0 >/dev/null
  w2_cmd force-overlay-config-value bool $W2_FLAG disabled false >/dev/null
  rm -f $RUN/wifi2
  echo "doppio Wi-Fi spento: una sola rete"
}

w2_stato() {  # una riga per il rapporto
  if [ -f $CFG/doppio_wifi_no ]; then echo "spento (comando doppio_wifi_off)"; return; fi
  [ -f $RUN/wifi2 ] || { echo "non attivo"; return; }
  d=$(dumpsys wifi 2>/dev/null)
  s=$(echo "$d" | grep -o 'mMultiInternetConnectionState [0-9]*' | head -n 1 | tr -cd '0-9')
  n=$(echo "$d" | grep -c 'role=ROLE_CLIENT_SECONDARY')
  i=$(ip -br addr 2>/dev/null | awk '$1 ~ /^wlan/ && $1 != "wlan0" {print $1" "$3}' | head -n 1)
  echo "acceso (principale $(cat $RUN/wifi2) GHz) | stato richiesta ${s:-?} | seconda interfaccia: ${i:-nessuna} | gestori secondari: $n"
}

w2_comando() {  # doppio_wifi_on / doppio_wifi_off dal pannello o firmati
  if [ "$1" = on ]; then rm -f $CFG/doppio_wifi_no; rem_esito "$(w2_on)"
  else touch $CFG/doppio_wifi_no; rem_esito "$(w2_off)"; fi
}

w2_tick() {  # dal watcher ogni 5 s; il lavoro vero una volta al minuto
  [ -f $CFG/doppio_wifi_no ] && return 0
  n=$(cat $RUN/w2_n 2>/dev/null); is_num "$n" || n=0; n=$((n + 1)); echo $n > $RUN/w2_n
  [ $((n % 12)) = 1 ] || return 0
  b=$(w2_banda_principale); [ -n "$b" ] || return 0
  # mai acceso (avvio) o la rete principale ha cambiato banda: la richiesta va rifatta sull'altra banda
  [ "$(cat $RUN/wifi2 2>/dev/null)" = "$b" ] && return 0
  # tentativo fallito su questa banda: si riprova ogni 10 minuti, non ogni minuto (registro pulito)
  [ "$(cat $RUN/wifi2_ko 2>/dev/null)" = "$b" ] && [ $((n % 120)) != 1 ] && return 0
  if e=$(w2_on); then rm -f $RUN/wifi2_ko; else echo $b > $RUN/wifi2_ko; fi
  log "$e"
}
