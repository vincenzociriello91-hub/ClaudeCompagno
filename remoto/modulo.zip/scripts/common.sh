#!/system/bin/sh
# Variabili e funzioni comuni
CFG=/data/adb/odin2tweaks
CONF=$CFG/config.conf
LOG=$CFG/log.txt
RUN=/dev/odin2tweaks
SWAPF=$CFG/swap/swapfile
MODDIR=${MODDIR:-/data/adb/modules/odin2tweaks}
mkdir -p "$CFG" "$RUN" 2>/dev/null

is_num() { case $1 in ''|*[!0-9]*) return 1;; esac; return 0; }
is_pkg() { case $1 in ''|*[!a-zA-Z0-9_.]*) return 1;; esac; return 0; }
ram_mb() { awk '/MemTotal/{v=int($2/1024)} END{print v+0}' /proc/meminfo; }
mb_avail() { awk '/MemAvailable/{v=int($2/1024)} END{print v+0}' /proc/meminfo; }

load_conf() {
  [ -f "$CONF" ] || cp "$MODDIR/scripts/defaults.conf" "$CONF"
  . "$CONF"
  # valori di sicurezza se il file contiene errori
  case $PROFILE in balanced|performance|battery|turbo|server) ;; *) PROFILE=balanced;; esac
  case $CLOUD_PROFILE in balanced|performance|battery|turbo) ;; *) CLOUD_PROFILE=balanced;; esac
  case $FAN in quiet|auto|sport|max) ;; *) FAN=auto;; esac
  case $CLOUD_FAN in quiet|auto|sport|max) ;; *) CLOUD_FAN=quiet;; esac
  case $SWAPFILE in on|off|auto) ;; *) SWAPFILE=off;; esac
  case $CLOUD in on|off|auto) ;; *) CLOUD=auto;; esac
  case $AUTO_APPS in on|off) ;; *) AUTO_APPS=on;; esac
  case $GAMEMODE in on|off) ;; *) GAMEMODE=on;; esac
  case $GAMEMODE_DND in on|off) ;; *) GAMEMODE_DND=on;; esac
  case $CLOUD_QOS in on|off) ;; *) CLOUD_QOS=on;; esac
  case $CLOUD_NOIDLE in on|off) ;; *) CLOUD_NOIDLE=on;; esac
  case $AUTO_HZ in on|off) ;; *) AUTO_HZ=on;; esac
  case $REPORT in on|off) ;; *) REPORT=on;; esac
  case $SERVER_MODE in auto|off) ;; *) SERVER_MODE=auto;; esac
  case $SERVER_FAN in quiet|auto|sport|max) ;; *) SERVER_FAN=auto;; esac
  case $SERVER_CHARGE_LIMIT in on|off) ;; *) SERVER_CHARGE_LIMIT=on;; esac
  is_num "$SERVER_BATT_STOP" || SERVER_BATT_STOP=12
  is_num "$SERVER_HOT" || SERVER_HOT=80
  is_num "$SERVER_PAUSE" || SERVER_PAUSE=88
  [ $SERVER_PAUSE -lt 75 ] && SERVER_PAUSE=75; [ $SERVER_PAUSE -gt 92 ] && SERVER_PAUSE=92
  is_num "$SERVER_SCREEN_S" || SERVER_SCREEN_S=60
  [ "$CLOUD_HZ" = auto ] || is_num "$CLOUD_HZ" || CLOUD_HZ=120
  case $ZRAM_ALGO in default|lz4|zstd|lzo|lzo-rle) ;; *) ZRAM_ALGO=default;; esac
  [ "$ZRAM" = default ] || is_num "$ZRAM" || ZRAM=default
  is_num "$SWAPFILE_MB" || SWAPFILE_MB=4096
  [ "$SWAPFILE_MB" -lt 512 ] && SWAPFILE_MB=512
  [ "$SWAPFILE_MB" -gt 16384 ] && SWAPFILE_MB=16384
  is_num "$SWAP_THRESHOLD_MB" || SWAP_THRESHOLD_MB=1200
}

set_conf() {  # set_conf CHIAVE valore
  [ -f "$CONF" ] || cp "$MODDIR/scripts/defaults.conf" "$CONF"
  v=$(printf '%s' "$2" | sed 's/[&|\\]/\\&/g')
  if grep -q "^$1=" "$CONF"; then sed -i "s|^$1=.*|$1=$v|" "$CONF"
  else printf '%s=%s\n' "$1" "$2" >> "$CONF"; fi
}

w() { [ -e "$2" ] && echo "$1" > "$2" 2>/dev/null; }

# Lettura sicura delle impostazioni di Android: "settings" a volte fallisce
# (es. output su file) e stampa un messaggio di errore al posto del valore.
# Restituisce il valore solo se valido (numero o null), altrimenti ERR.
sget() {
  v=$(settings get $1 $2 </dev/null 2>/dev/null)
  case $v in
    null) echo null ;;
    ""|*[!0-9.]*) echo ERR ;;
    *) echo $v ;;
  esac
}
sput() { settings put $1 $2 "$3" </dev/null >/dev/null 2>&1; }
sdel() { settings delete $1 $2 </dev/null >/dev/null 2>&1; }

log() {
  s=$(stat -c %s "$LOG" 2>/dev/null || echo 0)
  [ "$s" -gt 65536 ] && { tail -n 300 "$LOG" > "$LOG.tmp" && mv "$LOG.tmp" "$LOG"; }
  echo "$*" >> "$LOG"
}

# ferma il processo in background solo se è davvero il nostro
stop_watcher() {
  p=$(cat "$RUN/watch.pid" 2>/dev/null)
  is_num "$p" || return 0
  [ -r /proc/$p/cmdline ] || { rm -f "$RUN/watch.pid"; return 0; }
  tr '\0' ' ' < /proc/$p/cmdline 2>/dev/null | grep -q 'odin2tweaks/apply.sh watch' && { kill -TERM -"$p" 2>/dev/null || kill "$p" 2>/dev/null; }
  rm -f "$RUN/watch.pid"
}
