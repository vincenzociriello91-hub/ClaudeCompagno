# Installazione Odin 2 Portal Tweaks
ui_print "- Odin 2 Portal Tweaks v4.28"
[ "$API" -lt 30 ] 2>/dev/null && abort "! Richiede Android 11 o superiore"
PLAT=$(getprop ro.board.platform)
ui_print "- Piattaforma: $PLAT"
case $PLAT in kalama*) ;; *) ui_print "! Non è uno Snapdragon 8 Gen 2: alcune funzioni potrebbero non agire";; esac
RAM=$(awk '/MemTotal/{print int($2/1024)}' /proc/meminfo)
ui_print "- RAM: ${RAM} MB"
[ "$RAM" -gt 9000 ] && ui_print "! Ottimizzato per la Base 8 GB"

D=/data/adb/odin2tweaks
mkdir -p $D
C=$D/config.conf
if [ -f $C ]; then
  # aggiorna: aggiunge solo le impostazioni nuove, conserva quelle dell'utente
  grep -E '^[A-Z_]+=' $MODPATH/scripts/defaults.conf | while IFS= read -r l; do
    grep -q "^${l%%=*}=" $C || echo "$l" >> $C
  done
  # v4.18: DroidDeck tra le app PC anche dove PC_APPS era già stata scritta dalla v4.17
  grep -q '^PC_APPS=' $C && ! grep -q '^PC_APPS=.*com\.droiddeck\.launcher' $C && sed -i 's/^PC_APPS="\(.*\)"/PC_APPS="\1 com.droiddeck.launcher"/' $C
  ui_print "- Impostazioni precedenti conservate"
else
  cp $MODPATH/scripts/defaults.conf $C
fi
[ -f $D/apps.conf ] || cp $MODPATH/scripts/apps.default $D/apps.conf
rm -f $D/profile
chmod 600 $C $D/apps.conf

set_perm_recursive $MODPATH 0 0 0755 0644
set_perm_recursive $MODPATH/system/bin 0 2000 0755 0755
for f in service.sh action.sh apply.sh uninstall.sh; do set_perm $MODPATH/$f 0 0 0755; done
ui_print "- Menu: pulsante Azione in Magisk"
ui_print "- Comandi: su -c odin2 (da Termux)"
ui_print "- App Diario Odin: si installa da sola al riavvio"
ui_print "- Riavvia per attivare"
