#!/system/bin/sh
# Uso: apply.sh [boot|quick|watch|restore]
MODDIR=$(cd "${0%/*}" && pwd)
for s in common cpu fan mem net gamemode session backup remoto display watch diario; do . $MODDIR/scripts/$s.sh; done
load_conf

if [ "$1" = watch ]; then
  echo $$ > $RUN/watch.pid
  while true; do
    ( watcher ) && exit 0          # uscita normale: modulo disattivato o automatismi spenti
    log "processo in background interrotto da un errore: riavvio"
    sleep 10
  done
fi

if [ "$1" = boot ]; then
  # pulizia dopo un riavvio avvenuto durante un gioco
  dnd_restore
  noidle_off; srv_mode_off
  hz_restore; pc_off
fi

if [ "$1" = restore ]; then
  # modulo disattivato: CPU, GPU e ventola tornano ai valori originali
  PROFILE=balanced; FAN=auto
  apply_cpu; apply_fan; apply_mglru ripristina; rm -f $RUN/cpu_expected
  log "modulo disattivato: valori originali ripristinati"
  exit 0
fi

case $CLOUD in
  on)  cloud_on; PROFILE=$CLOUD_PROFILE; FAN=$CLOUD_FAN ;;
  off) cloud_off force ;;
esac
# server Minecraft acceso (scritto dal processo in background): modalità server, se nessuna app ha impostazioni proprie
[ -f $RUN/srv_mode ] && [ ! -f $RUN/override ] && { PROFILE=server; FAN=$SERVER_FAN; }
[ -f $RUN/srv_mode ] && [ -f $RUN/srv_caldo ] && [ ! -f $RUN/override ] && { PROFILE=battery; FAN=sport; }
# profilo dell'app aperta (scritto dal processo in background)
if [ -f $RUN/override ]; then
  read -r OP OF < $RUN/override
  case $OP in balanced|performance|battery|turbo|server) PROFILE=$OP;; esac
  case $OF in quiet|auto|sport|max) FAN=$OF;; esac
fi

[ "$1" = quick ] || log "
[$(date '+%d/%m %H:%M')] applico (${1:-manuale})"
apply_cpu
apply_fan
[ "$1" = quick ] && exit 0

apply_net_base
apply_mglru
[ "$1" = boot ] && apply_zram
case $SWAPFILE in
  on)  swap_on ;;
  off) swap_off ;;
esac
stop_watcher
# se lanciato da Termux o dall'app Magisk, esce dal loro spazio isolato
NS=""
if [ "$(readlink /proc/self/ns/mnt)" != "$(readlink /proc/1/ns/mnt 2>/dev/null)" ] && command -v nsenter >/dev/null 2>&1; then
  nsenter -t 1 -m true 2>/dev/null && NS="nsenter -t 1 -m --"
fi
setsid $NS sh $MODDIR/apply.sh watch </dev/null >/dev/null 2>&1 &
# app Diario Odin: installazione e permessi (dopo il processo in background, che non deve aspettare)
[ "$1" = boot ] && diario_setup
[ "$1" = boot ] && kernel_info
exit 0
