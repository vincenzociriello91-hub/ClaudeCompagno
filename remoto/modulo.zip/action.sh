#!/system/bin/sh
# Pulsante "Azione" di Magisk: menu con i tasti volume
MODDIR=$(cd "${0%/*}" && pwd)
. $MODDIR/scripts/common.sh
load_conf

key() {  # Vol+ = up, Vol- o 10 s senza tasti = conferma
  k=$(timeout 10 getevent -lq 2>/dev/null | grep -m1 -E 'KEY_VOLUME(UP|DOWN) +DOWN')
  case "$k" in *VOLUMEUP*) echo up;; *) echo down;; esac
}
next() {  # valore successivo nella lista (ciclico)
  cur=$1; first=""; found=0
  for v in $2; do
    [ -z "$first" ] && first=$v
    [ $found = 1 ] && { echo $v; return; }
    [ "$v" = "$cur" ] && found=1
  done
  echo $first
}
menu() {  # menu CHIAVE "valori" titolo
  eval cur=\$$1
  echo; echo "$3: [$cur]"; echo "  Vol+ = cambia   Vol- = conferma"
  while [ "$(key)" = up ]; do cur=$(next "$cur" "$2"); echo "  -> $cur"; done
  set_conf $1 $cur
}

sh $MODDIR/system/bin/odin2 status
echo
echo "================================="
echo "  Vol+  = LIBERA RAM ora"
echo "  Vol-  = menu impostazioni"
echo "  (attesa 10 s, poi menu)"
echo "================================="
if [ "$(key)" = up ]; then
  echo
  . $MODDIR/scripts/mem.sh
  clean_ram notifica
  exit 0
fi
menu PROFILE   "balanced performance battery turbo" "Profilo CPU/GPU"
menu FAN       "auto quiet sport max"         "Ventola"
menu SWAPFILE  "auto on off"                  "Swap su memoria interna"
menu CLOUD     "auto on off"                  "Modalità cloud gaming"
menu AUTO_APPS "on off"                       "Profili automatici per app"
menu GAMEMODE  "on off"                       "Modalità gioco"
sh $MODDIR/apply.sh
echo; echo "Impostazioni salvate e applicate."
[ "$(cat $RUN/fan_state 2>/dev/null)" = unsupported ] && echo "Nota: la curva ventola non è modificabile su questo kernel"
echo "Altro da Termux: su -c odin2 nettest | report | app list"
