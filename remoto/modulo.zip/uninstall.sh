#!/system/bin/sh
# Eseguito da Magisk all'avvio dopo la rimozione: il sistema non è ancora pronto,
# quindi il ripristino del Non disturbare aspetta la fine dell'avvio.
D=/data/adb/odin2tweaks
DND=0; [ -f $D/gm_dnd ] && DND=1
NOIDLE=$(cat $D/noidle_pkg 2>/dev/null)
TERMUX=0; [ -f $D/noidle_termux ] && TERMUX=1
[ -f $D/carica80 ] && echo 1 > /sys/class/qcom-battery/charging_enabled 2>/dev/null
[ -f $D/input_suspend_on ] && echo 0 > /sys/class/power_supply/battery/input_suspend 2>/dev/null
[ -f $D/charge_orig ] && cat $D/charge_orig > /sys/class/power_supply/battery/charge_control_end_threshold 2>/dev/null
SCR=""; [ -f $D/screen_orig ] && SCR=$(cat $D/screen_orig)
STAY=""; [ -f $D/stayon_orig ] && STAY=$(cat $D/stayon_orig)
HZ=""; [ -f $D/hz_orig ] && HZ=$(cat $D/hz_orig)
PH=""; [ -f $D/phantom_orig ] && PH=$(cat $D/phantom_orig)
# sempre: va tolta anche l'app Diario Odin installata dal modulo
  (
    until [ "$(getprop sys.boot_completed)" = 1 ]; do sleep 5; done
    sleep 10
    pm uninstall com.vincenzo.diarioodin
    [ $DND = 1 ] && [ "$(settings get global zen_mode </dev/null 2>/dev/null)" = 1 ] && cmd notification set_dnd off
    [ -n "$NOIDLE" ] && cmd deviceidle whitelist -$NOIDLE
    [ $TERMUX = 1 ] && cmd deviceidle whitelist -com.termux
    case $PH in "") ;; null) cmd device_config delete activity_manager max_phantom_processes;; *[!0-9]*) ;; *) cmd device_config put activity_manager max_phantom_processes $PH;; esac
    [ -n "$SCR" ] && settings put system screen_off_timeout "$SCR" </dev/null
    [ -n "$STAY" ] && settings put global stay_on_while_plugged_in "$STAY" </dev/null
    if [ -n "$HZ" ]; then
      set -- $HZ
      for kv in "peak_refresh_rate:$1" "min_refresh_rate:$2"; do
        k=${kv%%:*}; v=${kv#*:}
        case $v in ""|null|*[!0-9.]*) settings delete system $k </dev/null;; *) settings put system $k "$v" </dev/null;; esac
      done
    fi
  ) </dev/null >/dev/null 2>&1 &
for p in $(pgrep -f bedrock_server 2>/dev/null); do kill -CONT $p 2>/dev/null; done   # mai lasciare il server in pausa
rm -f /sdcard/Download/.odin_stato /sdcard/Download/.odin_stato.tmp /sdcard/Download/.odin_comando /sdcard/Download/.odin_esito*
rm -rf /data/adb/odin2tweaks
