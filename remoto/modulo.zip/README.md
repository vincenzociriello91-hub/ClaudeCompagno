# Odin 2 Portal Tweaks v4.6 – Base 8 GB, LineageOS (Magisk)

## Funzioni
- **Profilo turbo**: CPU minimo ~80%, GPU minimo 615 MHz, RAM (4224 MHz), cache LLCC e L3 al massimo
- **Profili automatici per app** (`/data/adb/odin2tweaks/apps.conf`): Winlator e Switch in performance + ventola sport, RetroArch e video in battery + quiet, ecc.
- **Modalità gioco**: all'avvio di un gioco chiude le app in background sacrificabili e attiva Non disturbare; all'uscita ripristina.
- **Cloud gaming** (GeForce NOW, Boosteroid, Xbox Cloud), attivo da solo quando apri l'app:
  - Wi-Fi in bassa latenza (scheda senza risparmio energetico)
  - priorità massima al traffico dell'app (DSCP EF → coda "voce" del Wi-Fi)
  - app esclusa dal risparmio energetico: la rete non viene mai sospesa
  - buffer di rete ampi per il flusso video, profilo balanced + ventola silenziosa
  - monitor della rete durante la partita: ping, picchi e pacchetti persi nel report
- **Test connessione** (`odin2 nettest`) e **report sessioni** (`odin2 report`).
- **Ventola** quiet/auto/sport/max, **zram fino a 6 GB** (quella di sistema non viene mai toccata: se serve se ne aggiunge una seconda), **swap su memoria interna** (auto), **profili CPU/GPU**.

Uscire da un gioco per meno di 30 secondi non interrompe profilo né sessione.

## Comandi (Termux: `su -c odin2 ...`)
```
odin2                         stato completo
odin2 nettest                 test connessione
odin2 report [N]              ultime N sessioni
odin2 report on|off           report automatico a fine partita
odin2 app now|list|add|del    profili per app
odin2 gamemode on|off | dnd on|off
odin2 cloud auto|on|off | add <pacchetto> | qos on|off
odin2 clean [notifica]         libera la RAM
odin2 widget                  crea i pulsanti per la Home (Termux:Widget)
odin2 hz on|off               frequenza schermo automatica per app
odin2 cloud hz <Hz|auto>      frequenza schermo nel cloud gaming (predefinita 120)
odin2 profile | fan | zram | swap | log
odin2 pc auto|off | add <pacchetto>   giochi PC in locale
odin2 esclusive on|off        una modalità alla volta (Cloud, PC, Server)
odin2 backup                  copia verificata delle partizioni di avvio (prima di cambiare kernel)
```

## Sicurezza
- Nessun file di sistema modificato: tutto a runtime, si annulla disattivando il modulo.
- Protezioni termiche della GPU e soglie di emergenza (hot/critical) mai toccate.
- La ventola non viene mai impostata sotto i 40 °C né vicino alle soglie di emergenza.
- Valori controllati: zram tra 512 MB e la RAM fisica, swap tra 512 MB e 16 GB con almeno 8 GB liberi di margine.
- Il Non disturbare viene tolto anche dopo un riavvio durante il gioco o dopo la disinstallazione.
- Il processo in background si riavvia da solo in caso di errore e si ferma se disattivi il modulo.

## Limiti
- Su LineageOS la velocità della ventola non si imposta a mano: il modulo sposta le soglie, se il kernel lo consente.
- Lo swap su memoria interna evita chiusure delle app ma non velocizza i giochi.
- Evita altri moduli che modificano CPU, GPU o zram: si sovrascriverebbero a vicenda.

## Novità v4.23 (il gioco PC usa futex_waitv?)
- Nei report dei giochi PC c'è una riga in più: `Wine: fsync (futex_waitv in uso)`, `Wine: esync (futex_waitv non usato)` oppure `Wine: sincronizzazione non rilevata`. Si legge, a gioco acceso, dalla memoria condivisa che `wineserver` apre. Serve a sapere se il kernel su misura viene sfruttato.

## Novità v4.22 (immagine di prova del kernel)
- Comando firmato `kernel_prova` (solo da remoto): scarica lo zip del kernel su misura dalla compilazione indicata (accettato solo con l'impronta approvata e solo se è per la versione esatta del kernel acceso), lo mette dentro una copia del `boot` di adesso con `magiskboot` e salva `boot_prova.img` e `boot_originale.img` in `Odin2_report/kernel_prova`. Non scrive nessuna partizione: l'immagine si avvia una volta dal PC con `fastboot boot`; se non parte basta riavviare.
- `kernel_info.txt` si riscrive anche quando cambia solo la data di compilazione del kernel (il kernel su misura ha la stessa versione dell'originale) e riporta in più: controlli di congestione TCP, swap attivi, moduli rifiutati dal kernel.

## Novità v4.21 (dati per il kernel)
- All'avvio, una volta per versione del kernel, scrive `Odin2_report/kernel_info.txt` (compilatore, opzioni che contano per i moduli, firme, simboli, stato del bootloader, nodi della carica) e `kernel_config.txt` (configurazione completa). Solo lettura: servono a ricompilare un kernel identico a quello installato.

## Novità v4.20 (stop del server: percorso vero)
- La v4.19 cercava la cartella del server dalla cartella di lavoro del processo: sulla Odin vera, sotto proot, quella risulta la radice di Debian, quindi non bastava. Il `console_server.txt` della v4.19 ha dato il percorso vero (`.../proot-distro/containers/debian/rootfs/root/claudemc`, proot-distro nuovo) e il modo sicuro: l'ingresso del server (fd 0) è proprio la console. Ora il percorso fisso è quello vero e in più si segue l'ingresso del server acceso.

## Novità v4.19 (stop del server: causa trovata)
- `console_server.txt` del 10/11 ha mostrato la causa: sulla Odin la cartella del server non è nel percorso che il modulo usava ("No such file or directory"). Ora il percorso si legge dal server acceso (la sua cartella di lavoro). Tornano a funzionare: stop pulito (remoto, batteria scarica, una modalità alla volta), conteggio dei giocatori connessi nei rapporti di consumo, riavvio del server bloccato.
- Prima di un riavvio comandato da remoto (installazione di un modulo, `riavvia_odin`) il server riceve lo stop e ha fino a 30 secondi per salvare il mondo.

## Novità v4.18 (Luna in Chrome, DroidDeck, stop del server)
- **Amazon Luna**: su Android non ha un'app, è un sito o una web app di Chrome. Ora la modalità cloud parte anche lì, in tutti e due i modi: scheda di Chrome (l'indirizzo lo legge l'app Diario Odin, che scrive in diretta ciò che compare a schermo) e web app installata sulla Home (conta il sito scritto nel suo pacchetto). Siti in `CLOUD_WEB` (predefinito `luna.amazon`). Limite: una volta riconosciuta vale finché Chrome resta a schermo, anche se cambi scheda. Serve l'app Diario attiva.
- **DroidDeck** (`com.droiddeck.launcher`) tra le app PC, anche sulle installazioni esistenti: fa girare Steam e i giochi Windows dentro di sé (Proton ARM64 + FEX), con molti processi figli.
- **Stop del server**: il 10/11 `ferma_server` ha risposto "server già spento" con il server acceso. Ora dice la verità ("server acceso ma lo stop non è arrivato: motivo") e, a ogni accensione del server, scrive `Odin2_report/console_server.txt` con il controllo della console (non manda nulla al server). Lo stesso controllo è nel rapporto remoto. La causa vera si corregge quando arriva quel file.

## Novità v4.17 (progetto "sistema perfetto": passo modulo)
Dall'analisi di `odin_info.txt` del 10/11/2026 (kernel 5.15.220) e dal rapporto remoto dello stesso giorno.
- **Una modalità alla volta** (Cloud, PC, Server), cambio automatico. Apri un gioco cloud o PC: si chiudono le app dell'altra modalità e il server Minecraft viene fermato con `stop` nella console (mondo salvato); quando esci dal gioco il server riparte da solo. Se il server parte senza un gioco a schermo, si chiudono le app di gioco rimaste aperte. Con un gioco a schermo vince sempre il gioco. `odin2 esclusive on|off`.
- **Giochi PC** (`PC_APPS`: Winlator, GameNative, GameHub; altre con `odin2 pc add <pacchetto>`): profilo performance, ventola sport, modalità gioco e limite dei "processi figli" di Android tolto finché l'app è a schermo (Android non chiude Wine/Box64 a metà partita). Il valore di prima torna all'uscita, al riavvio e alla disinstallazione.
- **MGLRU accesa**: il kernel ce l'ha ma spenta (`0x0000`). `MGLRU=off` nel file di configurazione per tornare indietro.
- **zram aggiuntiva**: all'avvio del 10/11 non era stata creata ("zram1: dispositivo non trovato"): causa probabile: il dispositivo compare qualche istante dopo `hot_add`; ora si aspetta fino a 10 secondi (da confermare col prossimo rapporto).
- **`odin2 backup`** (anche da remoto: azione `backup`): copia compressa di boot, init_boot, vendor_boot, dtbo, vbmeta, recovery, vendor_dlkm, system_dlkm dello slot attivo in `Odin2_report/backup_kernel` (arriva su Drive), ogni copia riletta e confrontata con l'originale; esito in `backup_partizioni.txt`. Solo lettura. Va fatto prima di cambiare kernel.
- Restano per il kernel nuovo (il modulo li userà da solo quando ci saranno): BBR (ora solo reno/cubic), `futex_waitv` per Proton, limite di carica vero (ora c'è solo `charge_control_limit`, un regolatore di corrente a livelli).

## Novità v4.12 (protezione dal calore e ventola)
- **Protezione della Odin:** se con il server acceso la CPU resta a 88 °C o più per 90 secondi, il server Minecraft viene messo in pausa (fermo, mondo intatto) e arriva una notifica. Riparte da solo quando la CPU scende di 15 °C. Soglia in config.conf (`SERVER_PAUSE`, sempre tra 75 e 92 °C). Il server non resta mai in pausa: riprende quando si spegne la modalità server, prima dello stop per batteria scarica e alla disinstallazione.
- Nel file per il pannello anche **livello della ventola**, temperatura GPU, pausa per calore e limite di carica attivo.

## Novità v4.11 (stato della Odin nel pannello del server)
- Con il server Minecraft acceso, ogni 30 secondi il modulo scrive batteria, carica, temperature, consumo e da quanto è accesa la Odin nel file `/sdcard/Download/.odin_stato` (fuori da Odin2_report: non va su Drive). Il pannello del server lo usa per la scheda **Odin**, perché Termux da solo non può leggere questi dati. Il file viene cancellato a server spento e alla disinstallazione.

## Novità v4.10 (consumo reale del server)
- Il riepilogo `consumo_server.txt` mostra per primo il **consumo reale** misurato con il contatore di carica della batteria (quanta carica è uscita davvero). Le misure istantanee restano sotto, per confrontare "solo bot" e "giocatori connessi", ma sono più alte del reale: sulla Odin 1,69 W misurati contro circa 1,2 W reali, perché il modulo sveglia la CPU proprio quando misura.
- Corretta la durata tra parentesi, che era sbagliata.

## Novità v4.9 (modalità server completa)
Con il server Minecraft acceso, la modalità server ora fa anche:
- **Batteria scarica**: sotto il 12% senza caricatore salva il mondo, ferma il server in modo pulito e ti avvisa (niente mondo rovinato da uno spegnimento improvviso).
- **Server protetto**: Android non lo chiude mai per liberare RAM; gira sui core veloci (3-7) con priorità alta.
- **Riavvio se si blocca**: registro fermo da 5 minuti = server bloccato; lo chiude e riparte da solo, con notifica.
- **Limite di carica**: con il caricatore attaccato tiene la batteria tra 60% e 80% (se il kernel lo permette; altrimenti lo scrive nel registro).
- **Schermo**: si spegne da solo dopo 1 minuto senza tocchi; il tempo di prima torna quando il server si spegne.
- **Indirizzo nuovo**: se il router cambia l'IP della Odin, notifica con l'indirizzo giusto del pannello.
- **Calore**: CPU oltre 80 °C = server più leggero e ventola più forte, finché non scende a 70 °C.
- Tutto regolabile in config.conf (SERVER_BATT_STOP, SERVER_CHARGE_LIMIT, SERVER_HOT, SERVER_SCREEN_S) e tutto torna com'era quando il server si spegne, al riavvio e alla disinstallazione.

## Novità v4.8 (modalità server)
- Nuovo profilo **server**, accanto a battery, balanced, performance e turbo: CPU senza i picchi più alti (che consumano e scaldano senza servire a un server), minimo di fabbrica, GPU al minimo.
- **Si attiva da sola** quando parte il server Minecraft (`bedrock_server` in Termux) e si spegne quando il server si ferma. Oltre al profilo: Termux escluso dal risparmio energetico (Android non lo addormenta a schermo spento) e Wi-Fi senza risparmio energetico (niente lag per chi gioca). Quando il server si spegne tutto torna com'era.
- Se apri un gioco con impostazioni proprie, vale il gioco; quando lo chiudi torna la modalità server.
- Comandi: `odin2 profile server` (a mano), `odin2 server auto|off` (attivazione automatica). Nuovo pulsante "Profilo Server" con `odin2 widget`.

## Novità v4.7 (consumo del server Minecraft)
- Quando il server di Claude Compagno (`bedrock_server` in Termux) è acceso, anche a schermo spento, il modulo misura ogni 30 s il consumo vero dalla batteria (corrente x tensione).
- Separa "solo il bot" da "giocatori connessi" (letti dal registro del server) e calcola quanto dura la batteria da 100% a 0% in ciascun caso.
- Ogni 10 minuti aggiorna `Download/Odin2_report/consumo_server.txt`; quando il server si spegne scrive `AAAAMMGG_HHMM_minecraft_server.txt` e manda una notifica.
- Le misure sotto carica non contano (la corrente è quella che entra): per misurare stacca il caricatore.

## Novità v4.6 (Diario Odin 1.1, dopo il primo report reale)
- Riconosce l'app già aperta quando il Diario parte (prima finiva sotto "UI di sistema").
- Schermate senza barra di stato e tasti di navigazione ripetuti (restano quando apri la tendina).
- Chiusure delle app leggibili: nome dell'app e motivo ("tolta dalle app recenti" = [TU], "per liberare memoria" = [ODIN]).
- Nel primo minuto dopo l'avvio, prima che il root sia pronto, i tocchi sui pulsanti contano già come [TU].

## Novità v4.5
- **App Diario Odin**, installata e attivata dal modulo al riavvio (Accessibilità, notifiche, accesso ai file, root: nessuna conferma da dare).
  Registra tutto ciò che compare a schermo: testi, app aperte, tocchi, pulsanti, testo scritto, notifiche (arrivate/aperte/scartate), toast, schermo, batteria, rete, Bluetooth, cuffie, volume, app installate/rimosse, crash, blocchi (ANR) e app chiuse dal sistema.
  Ogni riga dice chi l'ha causata: **[TU]** (tocco o pulsante reale nei 2 secondi prima, letto via root senza ritardi nei giochi) o **[ODIN]**.
  Report in `Download/Odin2_report`: `schermo_AAAAMMGG_HHMM.txt` per ogni sessione (si chiude dopo 5 minuti di standby, allo spegnimento o col pulsante dell'app) e `schermo_giorno_AAAAMMGG.txt` con il riepilogo del giorno. Tenuti 30 giorni.
- Disinstallando il modulo si disinstalla anche l'app. Disattivandolo l'app resta: per fermarla si spegne in Accessibilità.

## Novità v4.4
- La pulizia dei report (tenuti gli ultimi 30) tocca solo i report di partita: gli altri file in
  Download/Odin2_report (installazione, resoconto, controlli) non vengono più cancellati.
- Messaggio d'uso di `odin2 cloud` con l'opzione `hz`.

## Novità v4.3
- Report automatico a fine partita (almeno 2 minuti): file in Download/Odin2_report con dati della
  sessione, stato finale e registro, più una notifica. Tenuti gli ultimi 30. `odin2 report off` per spegnerlo.

## Novità v4.2
- Nuovo profilo **turbo**: CPU con minimo ~80%, GPU minimo 615 MHz, RAM DDR a 4224 MHz, cache LLCC
  a 1066 MHz e L3 a 1805 MHz, priorità alla memoria. Mai oltre i massimi di fabbrica, protezioni
  termiche sempre attive. Si usa per app (apps.conf) o a mano; pulsante "Profilo Turbo" nei widget.
- Stato: riga "Memoria" con le frequenze attuali di RAM e cache.

## Novità v4.1 (dal resoconto reale)
- Lettura sicura delle impostazioni di Android: se "settings" fallisce, il modulo non cambia la frequenza
  dello schermo e non salva valori sbagliati (prima poteva salvare un messaggio di errore come valore).
- Test di rete: riconosce i canali DFS (52-144) e consiglia un canale fisso 36-48; avvisa sotto -65 dBm;
  mostra velocità di ricezione e standard Wi-Fi.

## Novità v4.0
- Frequenza dello schermo per app (60/90/120/144/165 Hz): retro-gaming e video a 60 Hz,
  cloud gaming a 120 Hz, gli altri invariati. 5a colonna di apps.conf per sceglierla.
  La preferenza originale torna all'uscita dall'app, dopo un riavvio, alla disattivazione e alla disinstallazione.
- Salute della batteria nello stato (capacità attuale rispetto a quella da nuova).
- Test di rete: riconosce i router che rispondono lenti ai ping e non dà consigli sbagliati sul Wi-Fi.

## Novità v3.9
- Pulsante "Libera RAM" sulla schermata Home (Termux:Widget): un tocco, notifica con i MB liberati.
  Creato in automatico con `su -c odin2 widget`, insieme ai pulsanti dei profili e dello stato.
- Pulsante Azione di Magisk: Vol+ subito = libera RAM, Vol- = menu impostazioni.
- La pulizia chiude solo le app in background: musica e app aperte restano.

## Novità v3.8 (correzione dai dati reali)
- Le "spinte" temporanee della CPU che LineageOS dà all'apertura di un'app non vengono più
  memorizzate né reimposte: prima la CPU poteva restare bloccata al massimo finché l'app era aperta.
- Il profilo memorizza i valori voluti, non quelli letti. Il minimo viene solo rialzato (performance)
  e il massimo solo abbassato (battery): il modulo non contrasta mai il sistema.
- La GPU torna sempre alla frequenza minima di fabbrica fuori dal profilo performance.
- 75 test superati su 75 con BusyBox e con mksh/toybox.

## Novità v3.7 (correzione importante dai dati reali)
- La zram di sistema (4 GB lzo-rle) non viene più spenta né ridimensionata: sulla Odin 2 Portal il kernel
  non accetta la riconfigurazione e la zram restava spenta. Ora, se serve, se ne aggiunge una seconda (zram1).
- Se una zram non viene accettata, il registro riporta il passaggio e l'errore esatto.
- swapon prova anche senza priorità se l'opzione non è supportata (anche per lo swap su file).
- 71 test superati su 71 con BusyBox e con mksh/toybox, più 16 test sulla zram nella situazione reale.

## Novità v3.6 (dati reali dalla console)
- LineageOS su Odin 2 Portal non attiva nessuna zram: ora il modulo la crea (6 GB) invece di rinunciare.
- Il registro conserva anche ciò che succede all'avvio (prima veniva sovrascritto dai comandi manuali).
- Test reale della ventola: il modulo prova a scrivere ogni soglia e riporta quante sono davvero modificabili.

## Novità v3.5 (quarta revisione)
- Verificato anche con BusyBox in modalità standalone, la shell con cui Magisk esegue gli script del modulo.
- Spazio libero letto con `df -P`: BusyBox spezzava la riga con nomi di disco lunghi.
- Analisi statica con ShellCheck: nessun errore reale.
- Sensori assenti mostrati come "n/d" invece di 0 °C.
- 69 test superati su 69 sia con BusyBox sia con mksh/toybox.

## Novità v3.4 (terza revisione)
- Disattivando il modulo, CPU, GPU e ventola tornano ai valori originali anche se il profilo era performance/sport.
- Riapplicazione delle frequenze sicura: il massimo non viene mai rialzato (potrebbe essere un limite termico).
- Comandi da Termux o dall'app Magisk: il processo in background esce dal loro spazio isolato
  e l'app di cloud gaming viene riconosciuta in modo affidabile.
- 69 test superati su 69 con mksh e toybox.

## Novità v3.3
- Cloud gaming: priorità del traffico, esclusione dal risparmio energetico, buffer UDP più ampi,
  profilo balanced, monitor della rete con risultati nel report. Tutto viene annullato all'uscita
  dall'app, dopo un riavvio e alla disinstallazione. 65 test superati su 65.

## Novità v3.2 (seconda revisione)
- Corretto un errore critico di calcolo a 32 bit della shell di Android: la zram poteva essere azzerata.
- Lo swap viene provato subito: se il kernel non lo supporta, il file viene cancellato e non viene ricreato a ogni avvio.
- Con swap "off" il file viene eliminato per liberare spazio.
- Se il sistema cambia le frequenze CPU, il profilo viene riapplicato entro 30 secondi.
- La GPU torna al suo minimo originale invece che al più basso possibile.
- Il processo in background si chiude da solo se ne parte uno nuovo: mai due copie attive.
- Testato con mksh e toybox (shell e strumenti di Android): 50 test superati su 50.

## Novità v3.1
Revisione completa: rimossi force_clk_on e la disattivazione del throttling GPU, rimosso lo swap via loop device,
corretto il Non disturbare che poteva restare acceso, rilevamento app quasi a costo zero, log a dimensione fissa,
spazio libero letto correttamente, supervisore del processo in background, validazione di tutti i valori.
