#!/system/bin/sh
MODDIR=$(cd "${0%/*}" && pwd)
until [ "$(getprop sys.boot_completed)" = 1 ]; do sleep 5; done
sleep 20   # lascia finire l'avvio dei servizi di sistema
sh $MODDIR/apply.sh boot
